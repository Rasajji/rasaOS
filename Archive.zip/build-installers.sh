#!/usr/bin/env bash
# Build all Rasa OS installers supported on this host.
# On macOS: builds the .pkg. On Linux: builds .deb + tarball.
# Run from anywhere; outputs go to install/RasaOS-<ver>-<os>-<arch>.*
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

command -v cargo >/dev/null || { echo "cargo required" >&2; exit 1; }
(cd "$ROOT" && cargo build --release)

case "$(uname -s)" in
  Darwin)
    bash "$ROOT/install/macos/build-pkg.sh"
    ;;
  Linux)
    bash "$ROOT/install/scripts/stage.sh" /usr/local
    bash "$ROOT/install/linux/make-tarball.sh"
    bash "$ROOT/install/linux/build-deb.sh" 2>/dev/null || \
      echo "dpkg-deb not available; built tarball only"
    ;;
  MINGW*|MSYS*|CYGWIN*)
    echo "built target/release/rasa.exe"
    echo "run install/windows/install.bat (as administrator) to install"
    ;;
  *)
    echo "unsupported host: $(uname -s)" >&2
    exit 1
    ;;
esac
echo "done — installers are in $ROOT/install/"