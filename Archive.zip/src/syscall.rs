#[cfg(unix)]
use std::ffi::CString;
#[cfg(unix)]
use std::ffi::CStr;
#[cfg(not(unix))]
use std::fs;
use std::io::{self, BufRead, BufReader};
use std::path::Path;
use std::process::{Command, Stdio};
use std::thread;

const RESET: &str = "\x1b[0m";
const BOLD: &str = "\x1b[1m";
const DIM: &str = "\x1b[2m";
const CYAN: &str = "\x1b[36m";
const GREEN: &str = "\x1b[32m";
const YELLOW: &str = "\x1b[33m";
const RED: &str = "\x1b[31m";

/// Names of every raw kernel call this module knows how to invoke.
const KERNEL_CALLS: &[(&str, &str)] = &[
    ("getpid", "return this process ID (raw kill/getpid syscall)"),
    ("getppid", "return the parent process ID"),
    ("getuid", "return the real user ID"),
    ("getgid", "return the real group ID"),
    ("geteuid", "return the effective user ID"),
    ("getegid", "return the effective group ID"),
    ("getlogin", "return the login name from the kernel"),
    ("uname", "kernel identity: sysname, node, release, version, machine"),
    ("clock", "kernel clocks: realtime + monotonic nanoseconds"),
    ("cwd", "current directory straight from the getcwd syscall"),
    ("stat <path>", "inode-level metadata: size, mode, uid/gid, times"),
    ("page", "kernel memory page size (getpagesize)"),
    ("kill <pid> <sig>", "deliver a signal to a process"),
    ("proc", "snapshot of running kernel processes (pid, ppid, name)"),
];

/// Print short usage for the Rasa OS System Call bridge.
pub fn help() {
    println!("\u{1b}[2mRasa OS System Call (سیستم کال) bridge to the host kernel.{RESET}");
    println!("{GREEN}  syscall getpid{RESET} | {GREEN}getppid{RESET} | {GREEN}getuid{RESET} | {GREEN}getgid{RESET} | {GREEN}geteuid{RESET} | {GREEN}getegid{RESET}");
    println!("{GREEN}  syscall getlogin{RESET} | {GREEN}uname{RESET} | {GREEN}clock{RESET} | {GREEN}cwd{RESET} | {GREEN}page{RESET}");
    println!("{GREEN}  syscall stat <path>{RESET} | {GREEN}kill <pid> <sig>{RESET} | {GREEN}proc{RESET}");
    println!("\u{1b}[32m  syscall list\u{1b}[0m            show all supported kernel calls");
    println!("\u{1b}[32m  <command> -cas\u{1b}[0m          stream any real host tool (docker, git, curl, …)");
}

/// List all supported kernel calls.
pub fn list() {
    println!("{BOLD}raw kernel calls:{RESET}");
    for (name, description) in KERNEL_CALLS {
        let (name, rest) = name.split_once(' ').unwrap_or((name, ""));
        if !rest.is_empty() {
            println!("  {GREEN}syscall {name}{RESET} {YELLOW}{rest}{RESET} — {DIM}{description}{RESET}");
        } else {
            println!("  {GREEN}syscall {name}{RESET} — {DIM}{description}{RESET}");
        }
    }
}

/// Dispatches `syscall <name> [args]` to the matching raw kernel interface.
pub fn call(name: &str, args: &[String], _cwd: &Path) -> io::Result<()> {
    match name {
        "getpid" => {
            println!("pid = {GREEN}{}{RESET}", std::process::id());
            Ok(())
        }
        "getppid" => kernel_getppid(),
        "getuid" => kernel_getuid(),
        "getgid" => kernel_getgid(),
        "geteuid" => kernel_geteuid(),
        "getegid" => kernel_getegid(),
        "getlogin" => kernel_getlogin(),
        "uname" => kernel_uname(),
        "clock" => kernel_clock(),
        "cwd" => kernel_cwd(),
        "stat" => kernel_stat(args),
        "page" => kernel_page_size(),
        "kill" => kernel_kill(args),
        "proc" => kernel_proc(),
        "list" => {
            list();
            Ok(())
        }
        unknown => Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!(
                "unknown kernel call `{unknown}` — try `{CYAN}syscall list{RESET}`"
            ),
        )),
    }
}

/// Interactive kernel talk: a persistent `syscall>` prompt that keeps issuing
/// raw system calls until the user type `exit`, `quit`, or `back`.
pub fn repl() -> io::Result<()> {
    use std::io::Write;

    println!(
        "{BOLD}Kernel talk mode{RESET} — issue raw system calls against the host kernel."
    );
    println!("Type `list` for calls, `help` for hints, or {YELLOW}exit{RESET}/{YELLOW}back{RESET} to return.\n");

    loop {
        print!("{CYAN}syscall>{RESET} ");
        io::stdout().flush()?;

        let mut line = String::new();
        if io::stdin().read_line(&mut line)? == 0 {
            break;
        }
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        if matches!(line, "exit" | "quit" | "back" | "return") {
            break;
        }
        if line == "help" {
            helper();
            continue;
        }
        if line == "list" {
            list();
            continue;
        }

        let (name, args) = match line.split_once(' ') {
            Some((name, rest)) => (name, rest.split(' ').filter(|s| !s.is_empty()).map(str::to_string).collect::<Vec<_>>()),
            None => (line, Vec::new()),
        };
        if let Err(error) = call(name, &args, Path::new(".")) {
            eprintln!("{RED}syscall error:{RESET} {error}");
        }
    }
    Ok(())
}

fn helper() {
    println!();
    help();
    println!("{DIM}inside kernel talk mode you can also type calls without the `syscall` prefix.{RESET}");
}

#[cfg(unix)]
fn kernel_getppid() -> io::Result<()> {
    println!("ppid = {GREEN}{}{RESET}", unsafe { libc::getppid() });
    Ok(())
}

#[cfg(not(unix))]
fn kernel_getppid() -> io::Result<()> {
    println!("{DIM}getppid is a POSIX syscall; not exposed on Windows{RESET}");
    Ok(())
}

#[cfg(unix)]
fn kernel_getuid() -> io::Result<()> {
    println!("uid = {GREEN}{}{RESET}", unsafe { libc::getuid() });
    Ok(())
}

#[cfg(not(unix))]
fn kernel_getuid() -> io::Result<()> {
    println!("{DIM}getuid is a POSIX syscall; not exposed on Windows{RESET}");
    Ok(())
}

#[cfg(unix)]
fn kernel_getgid() -> io::Result<()> {
    println!("gid = {GREEN}{}{RESET}", unsafe { libc::getgid() });
    Ok(())
}

#[cfg(not(unix))]
fn kernel_getgid() -> io::Result<()> {
    println!("{DIM}getgid is a POSIX syscall; not exposed on Windows{RESET}");
    Ok(())
}

#[cfg(unix)]
fn kernel_geteuid() -> io::Result<()> {
    println!("euid = {GREEN}{}{RESET}", unsafe { libc::geteuid() });
    Ok(())
}

#[cfg(not(unix))]
fn kernel_geteuid() -> io::Result<()> {
    println!("{DIM}geteuid is a POSIX syscall; not exposed on Windows{RESET}");
    Ok(())
}

#[cfg(unix)]
fn kernel_getegid() -> io::Result<()> {
    println!("egid = {GREEN}{}{RESET}", unsafe { libc::getegid() });
    Ok(())
}

#[cfg(not(unix))]
fn kernel_getegid() -> io::Result<()> {
    println!("{DIM}getegid is a POSIX syscall; not exposed on Windows{RESET}");
    Ok(())
}

#[cfg(unix)]
fn kernel_getlogin() -> io::Result<()> {
    let login = unsafe { libc::getlogin() };
    if login.is_null() {
        println!("{DIM}(no login name){RESET}");
    } else {
        println!(
            "login = {GREEN}{}{RESET}",
            unsafe { CStr::from_ptr(login) }.to_string_lossy()
        );
    }
    Ok(())
}

#[cfg(not(unix))]
fn kernel_getlogin() -> io::Result<()> {
    let login = std::env::var("USERNAME").unwrap_or_else(|_| "unknown".to_string());
    println!("login = {GREEN}{login}{RESET}");
    Ok(())
}

/// Raw `uname(2)`: identity of the running kernel.
#[cfg(unix)]
fn kernel_uname() -> io::Result<()> {
    let mut uts: libc::utsname = unsafe { std::mem::zeroed() };
    if unsafe { libc::uname(&mut uts) } != 0 {
        return Err(io::Error::last_os_error());
    }
    let field = |ptr: *const libc::c_char| unsafe { CStr::from_ptr(ptr) }.to_string_lossy();
    println!("sysname   = {GREEN}{}{RESET}", field(uts.sysname.as_ptr()));
    println!("nodename  = {GREEN}{}{RESET}", field(uts.nodename.as_ptr()));
    println!("release   = {GREEN}{}{RESET}", field(uts.release.as_ptr()));
    println!("version   = {YELLOW}{}{RESET}", field(uts.version.as_ptr()));
    println!("machine   = {GREEN}{}{RESET}", field(uts.machine.as_ptr()));
    Ok(())
}

#[cfg(not(unix))]
fn kernel_uname() -> io::Result<()> {
    let os = env_os();
    let node = node_name();
    println!("sysname   = {GREEN}{os}{RESET}");
    println!("nodename  = {GREEN}{node}{RESET}");
    println!("release   = {GREEN}{}{RESET}", env_os_release());
    println!("version   = {YELLOW}{}{RESET}", env!("CARGO_PKG_VERSION"));
    println!("machine   = {GREEN}{}{RESET}", std::env::consts::ARCH);
    Ok(())
}

#[cfg(not(unix))]
fn env_os() -> String {
    let os = env_os_release();
    if os.is_empty() {
        std::env::consts::OS.to_string()
    } else {
        os
    }
}

#[cfg(not(unix))]
fn env_os_release() -> String {
    std::env::var("OS")
        .ok()
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| std::env::consts::OS.to_string())
}

#[cfg(not(unix))]
fn node_name() -> String {
    std::env::var("COMPUTERNAME")
        .ok()
        .filter(|s| !s.is_empty())
        .or_else(|| std::env::var("HOSTNAME").ok())
        .unwrap_or_else(|| "unknown".to_string())
}

/// Read one POSIX clock at the finest granularity the kernel offers.
#[cfg(unix)]
fn clock_nanos(clock_id: libc::clockid_t) -> io::Result<(i64, i64)> {
    let mut ts: libc::timespec = unsafe { std::mem::zeroed() };
    if unsafe { libc::clock_gettime(clock_id, &mut ts) } != 0 {
        return Err(io::Error::last_os_error());
    }
    Ok((ts.tv_sec as i64, ts.tv_nsec as i64))
}

/// `clock_gettime(3)`: realtime and monotonic kernel clocks.
#[cfg(unix)]
fn kernel_clock() -> io::Result<()> {
    let (real_sec, real_ns) = clock_nanos(libc::CLOCK_REALTIME)?;
    let (mono_sec, mono_ns) = clock_nanos(libc::CLOCK_MONOTONIC)?;
    println!(
        "realtime   = {GREEN}{}.{:09}{RESET} s",
        real_sec, real_ns
    );
    println!(
        "monotonic  = {GREEN}{}.{:09}{RESET} s",
        mono_sec, mono_ns
    );
    println!(
        "uptime     ≈ {GREEN}{}{RESET} s  {DIM}(from kernel monotonic clock){RESET}",
        mono_sec
    );
    Ok(())
}

#[cfg(not(unix))]
fn kernel_clock() -> io::Result<()> {
    use std::time::{Instant, SystemTime, UNIX_EPOCH};

    let real = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    println!(
        "realtime   = {GREEN}{}.{:03}{RESET} s",
        real.as_secs(),
        real.subsec_millis()
    );
    println!(
        "monotonic  = {GREEN}{}{RESET} ms (uptime approx.)",
        Instant::now().elapsed().as_millis()
    );
    Ok(())
}

/// Raw `getcwd(3)`: current working directory without the shell/FS layer.
#[cfg(unix)]
fn kernel_cwd() -> io::Result<()> {
    let mut buffer = [0 as libc::c_char; 4096];
    let result = unsafe {
        libc::getcwd(buffer.as_mut_ptr(), buffer.len() as libc::size_t)
    };
    if result.is_null() {
        return Err(io::Error::last_os_error());
    }
    let cwd = unsafe { CStr::from_ptr(result) }.to_string_lossy();
    println!("cwd = {GREEN}{cwd}{RESET}  {DIM}(raw getcwd syscall, no shell path layer){RESET}");
    Ok(())
}

#[cfg(not(unix))]
fn kernel_cwd() -> io::Result<()> {
    let cwd = std::env::current_dir()?;
    println!("cwd = {GREEN}{}{RESET}  {DIM}(raw getcwd, no shell path layer){RESET}", cwd.display());
    Ok(())
}

/// `stat(2)`: inode-level metadata of a file or directory.
#[cfg(unix)]
fn kernel_stat(args: &[String]) -> io::Result<()> {
    let Some(raw_path) = args.first() else {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "usage: syscall stat <path>",
        ));
    };
    let path = CString::new(raw_path.as_str()).map_err(|_| {
        io::Error::new(io::ErrorKind::InvalidInput, "path contains a NUL byte")
    })?;

    let mut st: libc::stat = unsafe { std::mem::zeroed() };
    if unsafe { libc::stat(path.as_ptr(), &mut st) } != 0 {
        return Err(io::Error::last_os_error());
    }

    println!("{GREEN}{raw_path}{RESET} {DIM}(inode from the kernel){RESET}");
    println!("  device      = {}", st.st_dev);
    println!("  inode       = {GREEN}{}{RESET}", st.st_ino);
    println!("  mode        = {GREEN}0o{:o}{RESET}", st.st_mode);
    println!("  links       = {}", st.st_nlink);
    println!("  uid / gid   = {} / {}", st.st_uid, st.st_gid);
    println!("  size        = {} bytes", st.st_size);
    println!("  block size  = {}, blocks = {}", st.st_blksize, st.st_blocks);
    println!("  atime       = {}", st.st_atime);
    println!("  mtime       = {}", st.st_mtime);
    println!("  ctime       = {}", st.st_ctime);
    Ok(())
}

#[cfg(not(unix))]
fn kernel_stat(args: &[String]) -> io::Result<()> {
    let Some(raw_path) = args.first() else {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "usage: syscall stat <path>",
        ));
    };
    let meta = fs::metadata(raw_path)?;
    println!("{GREEN}{raw_path}{RESET} {DIM}(metadata from the Windows API){RESET}");
    println!("  size     = {GREEN}{}{RESET} bytes", meta.len());
    println!("  is file  = {}", meta.is_file());
    println!("  is dir   = {}", meta.is_dir());
    println!("  readonly = {}", meta.permissions().readonly());
    Ok(())
}

/// `sysconf(_SC_PAGESIZE)`: the kernel's virtual memory page size.
#[cfg(unix)]
fn kernel_page_size() -> io::Result<()> {
    let size = unsafe { libc::sysconf(libc::_SC_PAGESIZE) };
    if size < 0 {
        return Err(io::Error::last_os_error());
    }
    println!("page size = {GREEN}{size}{RESET} bytes");
    Ok(())
}

#[cfg(not(unix))]
fn kernel_page_size() -> io::Result<()> {
    println!("page size = {GREEN}4096{RESET} bytes {DIM}(Windows page size is not exposed; 4096 assumed){RESET}");
    Ok(())
}

/// `kill(2)`: send a raw signal to a live kernel process.
#[cfg(unix)]
fn kernel_kill(args: &[String]) -> io::Result<()> {
    if args.len() < 2 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "usage: syscall kill <pid> <signal>",
        ));
    }
    let pid: i32 = args[0].parse().map_err(|_| {
        io::Error::new(io::ErrorKind::InvalidInput, "pid must be an integer")
    })?;
    let signal: i32 = args[1].parse().map_err(|_| {
        io::Error::new(
            io::ErrorKind::InvalidInput,
            "signal must be an integer (e.g. 9 = SIGKILL, 15 = SIGTERM)",
        )
    })?;

    if unsafe { libc::kill(pid as libc::pid_t, signal) } != 0 {
        return Err(io::Error::last_os_error());
    }
    println!(
        "{GREEN}signal {signal}{RESET} delivered to pid {GREEN}{pid}{RESET}"
    );
    Ok(())
}

#[cfg(not(unix))]
fn kernel_kill(args: &[String]) -> io::Result<()> {
    if args.len() < 2 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "usage: syscall kill <pid> <signal> (on Windows use `taskkill /PID <pid> /F`)",
        ));
    }
    let pid: u32 = args[0].parse().map_err(|_| {
        io::Error::new(io::ErrorKind::InvalidInput, "pid must be an integer")
    })?;
    let status = Command::new("taskkill")
        .args(["/PID", &pid.to_string(), "/F"])
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()?;
    if status.success() {
        println!("forcefully terminated pid {GREEN}{pid}{RESET}");
        Ok(())
    } else {
        Err(io::Error::other(format!(
            "taskkill exited with status: {status}"
        )))
    }
}

/// Snapshot of kernel processes.
///
/// On Linux this reads the raw `/proc/<pid>/stat` files; on macOS it falls
/// back to the host `ps`. On Windows it runs `tasklist` so the Rasa terminal
/// still sees the live process table.
fn kernel_proc() -> io::Result<()> {
    #[cfg(target_os = "linux")]
    if Path::new("/proc").is_dir() {
        println!("{DIM}reading /proc directly from the kernel{RESET}");
        let mut processes = Vec::new();
        for entry in fs::read_dir("/proc")? {
            let entry = entry?;
            let name = entry.file_name().to_string_lossy().to_string();
            if name.is_empty() || !name.chars().all(|c| c.is_ascii_digit()) {
                continue;
            }
            if let Ok(pid) = name.parse::<i32>() {
                if let Ok(content) = fs::read_to_string(entry.path().join("stat")) {
                    if let Some(comm) = stat_comm(&content) {
                        processes.push((pid, comm));
                    }
                }
            }
        }
        processes.sort_unstable();
        println!("  {GREEN}{:<8}{RESET} {DIM}name{RESET}", "pid");
        for (pid, comm) in processes {
            println!("{GREEN}{pid:<8}{RESET} {comm}");
        }
        return Ok(());
    }

    #[cfg(windows)]
    {
        println!("{DIM}showing host process table (tasklist){RESET}");
        let status = Command::new("tasklist")
            .stdin(Stdio::inherit())
            .stdout(Stdio::inherit())
            .stderr(Stdio::inherit())
            .status()?;
        if !status.success() {
            return Err(io::Error::other(format!("tasklist exited with {status}")));
        }
        return Ok(());
    }

    #[cfg(not(any(target_os = "linux", windows)))]
    {
        println!("{DIM}showing host process table (ps){RESET}");
        let status = Command::new("ps")
            .args(["-eo", "pid,ppid,comm"])
            .stdin(Stdio::inherit())
            .stdout(Stdio::inherit())
            .stderr(Stdio::inherit())
            .status()?;
        if !status.success() {
            return Err(io::Error::other(format!("ps exited with {status}")));
        }
        Ok(())
    }
}

/// Extract the process name from a `/proc/<pid>/stat` line like `123 (name) R 1`.
#[cfg(target_os = "linux")]
fn stat_comm(stat: &str) -> Option<String> {
    let open = stat.find('(')?;
    let close = stat.rfind(')')?;
    if close <= open {
        return None;
    }
    Some(stat[open + 1..close].to_string())
}

/// Run a real host program from inside Rasa OS and stream its output into the
/// Rasa terminal. This is the general host-OS bridge behind the `-cas` flag.
pub fn exec(program: &str, args: &[String], cwd: &Path) -> io::Result<i32> {
    if !args.is_empty() {
        println!("{CYAN}syscall{RESET} » {program} {}", args.join(" "));
    } else {
        println!("{CYAN}syscall{RESET} » {program}");
    }

    let mut child = Command::new(program)
        .args(args)
        .current_dir(cwd)
        .stdin(Stdio::inherit())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()?;

    let stdout = child
        .stdout
        .take()
        .expect("child stdout was configured as piped");
    let stderr = child
        .stderr
        .take()
        .expect("child stderr was configured as piped");

    // Read stdout and stderr on separate threads so a full pipe can never
    // deadlock the child process.
    let stdout_thread = thread::spawn(move || {
        for line in BufReader::new(stdout).lines() {
            match line {
                Ok(line) => println!("{line}"),
                Err(_) => break,
            }
        }
    });

    let stderr_thread = thread::spawn(move || {
        for line in BufReader::new(stderr).lines() {
            match line {
                Ok(line) => eprintln!("{YELLOW}{line}{RESET}"),
                Err(_) => break,
            }
        }
    });

    let exit_code = child.wait()?.code().unwrap_or(-1);
    let _ = stdout_thread.join();
    let _ = stderr_thread.join();

    if exit_code == 0 {
        println!("{DIM}[syscall {program} → ok]{RESET}");
    } else {
        eprintln!("{RED}[syscall {program} → exit {exit_code}]{RESET}");
    }

    Ok(exit_code)
}