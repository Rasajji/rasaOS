use crossterm::cursor::{Hide, MoveTo, Show};
use crossterm::event::{read, Event, KeyCode};
use crossterm::terminal::{
    disable_raw_mode, enable_raw_mode, size, Clear, ClearType, EnterAlternateScreen,
    LeaveAlternateScreen,
};
use crossterm::ExecutableCommand;
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

#[path = "A1.rs"]
mod a1;
#[path = "A2.rs"]
mod a2;
#[path = "etc.rs"]
mod etc;
mod music_player;
mod syscall;

const VERSION: &str = env!("CARGO_PKG_VERSION");
const RESET: &str = "\x1b[0m";
const BOLD: &str = "\x1b[1m";
const DIM: &str = "\x1b[2m";
const CYAN: &str = "\x1b[36m";
const GREEN: &str = "\x1b[32m";
const YELLOW: &str = "\x1b[33m";
const RED: &str = "\x1b[31m";
const BLUE: &str = "\x1b[34m";
const MAGENTA: &str = "\x1b[35m";

struct RasaOs {
    cwd: PathBuf,
    running: bool,
    storage_root: PathBuf,
    music_root: PathBuf,
}

impl RasaOs {
    fn new() -> io::Result<Self> {
        let storage_root = rasa_storage_dir();
        let music_root = storage_root.join("music");
        fs::create_dir_all(&music_root)?;

        Ok(Self {
            cwd: env::current_dir()?,
            running: true,
            storage_root,
            music_root,
        })
    }

    fn boot(&mut self) {
        clear_terminal().ok();
        self.banner();
        self.welcome();

        while self.running {
            print!(
                "{GREEN}rasa{RESET}:{BLUE}{}{RESET}$ ",
                self.short_cwd().display()
            );
            if let Err(error) = io::stdout().flush() {
                eprintln!("{RED}stdout error:{RESET} {error}");
                break;
            }

            let mut line = String::new();
            match io::stdin().read_line(&mut line) {
                Ok(0) => break,
                Ok(_) => self.run_line(line.trim()),
                Err(error) => eprintln!("{RED}stdin error:{RESET} {error}"),
            }
        }

        println!("{CYAN}Rasa OS stopped.{RESET}");
    }

    fn run_line(&mut self, line: &str) {
        if line.is_empty() {
            return;
        }

        // Expand `alias` shortcuts (e.g. `ll='ls -l'`) before anything else.
        let line = a2::expand_aliases(line);

        // `-cas` bridge: any trailing "-cas" turns the line into a system call
        // against the host OS, e.g. `docker ps -cas` runs `docker ps`.
        if let Some(host_line) = strip_host_syscall(&line) {
            let parts = split_words(&host_line);
            if let Some(program) = parts.first() {
                match syscall::exec(program, &parts[1..], &self.cwd) {
                    Ok(0) => {}
                    Ok(code) => eprintln!("{YELLOW}program exited:{RESET} {code}"),
                    Err(error) => eprintln!("{RED}syscall:{RESET} {error}"),
                }
                return;
            }
        }

        let parts = split_words(&line);
        if parts.is_empty() {
            return;
        }

        let command = parts[0].as_str();
        let args = &parts[1..];

        if let Some(result) = a1::run(command, args) {
            if let Err(error) = result {
                eprintln!("{RED}{command}:{RESET} {error}");
            }
            return;
        }

        if let Some(result) = a2::run(command, args, &self.cwd) {
            if let Err(error) = result {
                eprintln!("{RED}{command}:{RESET} {error}");
            }
            return;
        }

        let result = match command {
            "/" => self.slash_panel(),
            "help" => self.help(),
            "about" => self.about(),
            "banner" => {
                self.banner();
                Ok(())
            }
            "clear" | "cls" => self.clear_screen(),
            "exit" | "shutdown" | "poweroff" => {
                self.running = false;
                Ok(())
            }
            "pwd" => self.pwd(),
            "ls" | "dir" => self.ls(args),
            "cd" => self.cd(args),
            "mkdir" => self.mkdir(args),
            "touch" => self.touch(args),
            "cat" => self.cat(args),
            "echo" => self.echo(args),
            "rm" | "del" => self.rm(args),
            "cp" | "copy" => self.cp(args),
            "mv" | "move" | "ren" => self.mv(args),
            "tree" => self.tree(args),
            "find" => self.find(args),
            "write" => self.write_file(args),
            "append" => self.append_file(args),
            "vi" | "vim" | "edit" => self.vim(args),
            "music" => self.music_command(args),
            "date" => self.date(),
            "uname" => self.uname(),
            "sysinfo" => self.sysinfo(),
            "syscall" | "kernel" => self.syscall_command(args),
            "run" | "!" => self.run_host(args),
            "etc" => etc::handle(args),
            unknown => {
                eprintln!("{RED}unknown command:{RESET} {unknown}");
                eprintln!("try `{YELLOW}help{RESET}`");
                Ok(())
            }
        };

        if let Err(error) = result {
            eprintln!("{RED}{command}:{RESET} {error}");
        }
    }

    fn banner(&self) {
        println!("{CYAN}{BOLD}");
        println!("╔══════════════════════════════════════════════╗");
        println!("║                 RASA OS CLI                  ║");
        println!("║          Rust Terminal Operating Shell       ║");
        println!("╚══════════════════════════════════════════════╝");
        println!("{RESET}{DIM}version {VERSION} • type `help` • type `exit` to stop{RESET}\n");
    }

    fn welcome(&self) {
        let seconds = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        let greeting = match (seconds / 3_600) % 24 {
            5..=11 => "Good morning",
            12..=17 => "Good afternoon",
            18..=22 => "Good evening",
            _ => "Welcome",
        };
        let messages = [
            "Your Rasa workspace is ready.",
            "Build something great today.",
            "The terminal is ready for your next command.",
            "Music, files, and tools are one command away.",
        ];
        let message = messages[(seconds as usize) % messages.len()];

        print!("{CYAN}{BOLD}{greeting}!{RESET} ");
        type_text(message, Duration::from_millis(14));
        println!();
        println!("{DIM}Type `help` to explore Rasa OS.{RESET}\n");
    }

    fn help(&self) -> io::Result<()> {
        println!(
            "{BOLD}{CYAN}Rasa OS {VERSION}{RESET} {DIM}· command reference · type `exit` to leave{RESET}"
        );
        head("CORE");
        row("/", "Rasa Panel — apps (Music …)");
        row("help", "show this reference");
        row("about", "what Rasa OS is");
        row("banner", "print boot banner");
        row("clear | cls", "clear the screen");
        row("exit | shutdown", "leave Rasa OS");

        head("FILES");
        row("pwd", "print working directory");
        row("ls | dir [path]", "list files");
        row("cd [path]", "change directory");
        row("mkdir <path>...", "create directories");
        row("touch <file>...", "create empty files");
        row("cat <file>...", "print file contents");
        row("write <file> <txt>", "write a file");
        row("append <file> <txt>", "append to a file");
        row("vi | vim | edit <f>", "edit with bundled Neovim");
        row("rm | del [-r] <p>...", "remove files/directories");
        row("cp | copy [-r] <f> <t>", "copy files/directories");
        row("mv | move <f> <t>", "rename / move");
        row("tree [path] [depth]", "directory tree");
        row("find <name> [path]", "search by name");
        row("echo <text>", "print text");

        head("NETWORK");
        a1::help();

        head("SYSTEM & ROOT");
        a2::help();

        head("APPS");
        row("music list", "list songs in Rasa Music");
        row("music add <path>", "import an audio file");
        row("music remove <name>", "delete a song");
        row("music open | play <n>", "play with built-in player");
        row("music storage", "show storage folder");

        head("HOST BRIDGE");
        row("run <program> [args]", "run a real terminal command");
        row("! <program> [args]", "shortcut for run");
        row("<anything> -cas", "system-call any host tool (docker, git, …)");

        head("KERNEL / SYSTEM CALLS");
        syscall::help();

        head("ETC → REAL /etc");
        etc::help();
        Ok(())
    }

    fn about(&self) -> io::Result<()> {
        println!("Rasa OS is a terminal OS-like shell written in Rust.");
        println!("This starter version runs on top of your current operating system.");
        println!("Rasa storage: {}", self.storage_root.display());
        println!("Modules:");
        println!("  A1  network extras (`my ip`, `arp -a`)");
        println!("  A2  system + root (`sudo res`, `su`, `uptime`, …) — registry: src/a2.sy");
        println!("  Syscall  host bridge (`<tool> -cas`) — run real host programs via src/syscall.rs");
        println!("  Syscall  deep kernel talk (`syscall getpid|uname|stat|clock|proc|…` via libc)");
        println!("Music: built-in Rasa Music Player (rodio) — not the OS media player.");
        println!("Next step can be a real bootable kernel, package manager, or TUI apps.");
        Ok(())
    }

    fn slash_panel(&mut self) -> io::Result<()> {
        loop {
            let choice = select_menu(
                "Rasa Panel",
                "Use ↑/↓ to move • Enter to open • Esc/q to close",
                &["Music", "Back"],
            )?;

            match choice {
                Some(0) => self.music_panel()?,
                _ => return Ok(()),
            }
        }
    }

    fn music_panel(&mut self) -> io::Result<()> {
        loop {
            let choice = select_menu(
                "Rasa Music",
                "Built-in player only · never opens system Music app",
                &[
                    "Add song to Rasa OS",
                    "List songs",
                    "Play song (Rasa player)",
                    "Remove song",
                    "Show storage folder",
                    "Back",
                ],
            )?;

            match choice {
                Some(0) => {
                    println!("Drag & drop the song file here, then press Enter.");
                    print!("song file> ");
                    io::stdout().flush()?;
                    let mut path = String::new();
                    io::stdin().read_line(&mut path)?;
                    self.add_music(path.trim())?;
                    wait_for_enter()?;
                }
                Some(1) => {
                    self.browse_music()?;
                }
                Some(2) => {
                    self.prompt_open_music()?;
                }
                Some(3) => {
                    print!("song name> ");
                    io::stdout().flush()?;
                    let mut name = String::new();
                    io::stdin().read_line(&mut name)?;
                    self.remove_music(name.trim())?;
                    wait_for_enter()?;
                }
                Some(4) => {
                    println!("{}", self.music_root.display());
                    wait_for_enter()?;
                }
                _ => return Ok(()),
            }
        }
    }

    fn clear_screen(&self) -> io::Result<()> {
        clear_terminal()
    }

    fn pwd(&self) -> io::Result<()> {
        println!("{}", self.cwd.display());
        Ok(())
    }

    fn ls(&self, args: &[String]) -> io::Result<()> {
        let mut show_all = false;
        let mut long = false;
        let mut paths: Vec<&str> = Vec::new();
        for arg in args {
            if arg == "-a" || arg == "--all" {
                show_all = true;
            } else if arg == "-l" {
                long = true;
            } else if arg.starts_with('-') && arg.len() > 1 {
                for flag in arg[1..].chars() {
                    match flag {
                        'a' => show_all = true,
                        'l' => long = true,
                        _ => {}
                    }
                }
            } else {
                paths.push(arg);
            }
        }

        let path = self.resolve(paths.first().map(|p| *p).unwrap_or("."));
        let mut entries = fs::read_dir(path)?.collect::<Result<Vec<_>, _>>()?;
        entries.sort_by_key(|entry| entry.file_name());

        for entry in entries {
            let metadata = entry.metadata()?;
            let name = entry.file_name().to_string_lossy().to_string();
            if !show_all && name.starts_with('.') {
                continue;
            }
            if long {
                println!("{}", format_long_entry(&metadata, &name));
            } else if metadata.is_dir() {
                println!("{BLUE}{name}/{RESET}");
            } else if is_executable(&metadata) {
                println!("{GREEN}{name}{RESET}");
            } else {
                println!("{name}");
            }
        }
        Ok(())
    }

    fn cd(&mut self, args: &[String]) -> io::Result<()> {
        let path = args
            .first()
            .map(|target| self.resolve(target))
            .unwrap_or_else(|| home_dir().unwrap_or_else(|| PathBuf::from(".")));
        let canonical = fs::canonicalize(path)?;
        if canonical.is_dir() {
            self.cwd = canonical;
            Ok(())
        } else {
            Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "not a directory",
            ))
        }
    }

    fn mkdir(&self, args: &[String]) -> io::Result<()> {
        require_args(args, "mkdir <path>...")?;
        for path in args {
            fs::create_dir_all(self.resolve(path))?;
        }
        Ok(())
    }

    fn touch(&self, args: &[String]) -> io::Result<()> {
        require_args(args, "touch <file>...")?;
        for path in args {
            fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(self.resolve(path))?;
        }
        Ok(())
    }

    fn cat(&self, args: &[String]) -> io::Result<()> {
        require_args(args, "cat <file>...")?;
        for path in args {
            print!("{}", fs::read_to_string(self.resolve(path))?);
        }
        Ok(())
    }

    fn echo(&self, args: &[String]) -> io::Result<()> {
        println!("{}", args.join(" "));
        Ok(())
    }

    fn write_file(&self, args: &[String]) -> io::Result<()> {
        if args.len() < 2 {
            return usage("write <file> <text>");
        }
        fs::write(self.resolve(&args[0]), args[1..].join(" "))
    }

    fn append_file(&self, args: &[String]) -> io::Result<()> {
        if args.len() < 2 {
            return usage("append <file> <text>");
        }
        let mut file = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(self.resolve(&args[0]))?;
        writeln!(file, "{}", args[1..].join(" "))
    }

    fn music_command(&self, args: &[String]) -> io::Result<()> {
        let Some(subcommand) = args.first().map(String::as_str) else {
            return usage("music <list|add|remove|open|storage> [value]");
        };

        match subcommand {
            "list" => self.list_music(),
            "add" => {
                if args.is_empty() {
                    return usage("music add <path-to-audio>");
                }
                self.add_music(&args[1..].join(" "))
            }
            "remove" | "delete" => {
                if args.len() != 2 {
                    return usage("music remove <name>");
                }
                self.remove_music(&args[1])
            }
            "open" | "play" => {
                if args.len() == 1 {
                    return self.prompt_open_music();
                }
                if args.len() != 2 {
                    return usage("music open <name>");
                }
                self.open_music(&args[1])
            }
            "storage" => {
                println!("{}", self.music_root.display());
                Ok(())
            }
            _ => usage("music <list|add|remove|open|storage> [value]"),
        }
    }

    fn add_music(&self, source: &str) -> io::Result<()> {
        let source_path = dropped_path(source);
        if source_path.as_os_str().is_empty() {
            return usage("music add <path-to-audio>");
        }

        let source_path = if source_path.is_absolute() {
            source_path
        } else {
            self.cwd.join(source_path)
        };
        if !source_path.is_file() {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!(
                    "song file was not found. Try drag & drop again, or use quotes: music add \"{}\"",
                    source_path.display()
                ),
            ));
        }

        let file_name = source_path
            .file_name()
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "invalid file name"))?;
        let destination = unique_destination(&self.music_root, file_name);
        fs::create_dir_all(&self.music_root)?;
        fs::copy(&source_path, &destination)?;

        println!(
            "{GREEN}added to Rasa Music:{RESET} {}",
            destination
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
        );
        Ok(())
    }

    fn list_music(&self) -> io::Result<()> {
        let entries = self.music_entries()?;

        if entries.is_empty() {
            println!("{DIM}Rasa Music is empty. Use `music add <path>` or press `/`.{RESET}");
            return Ok(());
        }

        for (index, entry) in entries.iter().enumerate() {
            let metadata = entry.metadata()?;
            let size = human_size(metadata.len());
            println!(
                "{:>2}. {} {DIM}({size}){RESET}",
                index + 1,
                entry.file_name().to_string_lossy()
            );
        }
        Ok(())
    }

    fn browse_music(&self) -> io::Result<()> {
        let entries = self.music_entries()?;
        if entries.is_empty() {
            println!("{DIM}Rasa Music is empty. Add a song first.{RESET}");
            wait_for_enter()?;
            return Ok(());
        }

        let items = entries
            .iter()
            .enumerate()
            .map(|(index, entry)| format!("{}. {}", index + 1, entry.file_name().to_string_lossy()))
            .collect::<Vec<_>>();
        let item_refs = items.iter().map(String::as_str).collect::<Vec<_>>();
        let choice = select_menu(
            "Rasa Music",
            "↑/↓ to browse • Enter to play (built-in) • Esc/q to return",
            &item_refs,
        )?;

        if let Some(index) = choice {
            // Always use the built-in Rasa player — never the system media app.
            self.play_music(&entries[index].path())?;
            wait_for_enter()?;
        }
        Ok(())
    }

    fn music_entries(&self) -> io::Result<Vec<fs::DirEntry>> {
        fs::create_dir_all(&self.music_root)?;
        let mut entries = fs::read_dir(&self.music_root)?
            .collect::<Result<Vec<_>, _>>()?
            .into_iter()
            .filter(|entry| entry.path().is_file())
            .collect::<Vec<_>>();
        entries.sort_by_key(|entry| entry.file_name());
        Ok(entries)
    }

    fn remove_music(&self, name: &str) -> io::Result<()> {
        let path = self.music_file_by_name(name)?;
        fs::remove_file(&path)?;
        println!("{GREEN}removed:{RESET} {}", path.display());
        Ok(())
    }

    fn open_music(&self, name: &str) -> io::Result<()> {
        let path = self.music_file_by_name(name)?;
        self.play_music(&path)
    }

    fn play_music(&self, path: &Path) -> io::Result<()> {
        // Built-in Rasa Music Player (rodio) — does not open the system player.
        music_player::play(path)
    }

    fn prompt_open_music(&self) -> io::Result<()> {
        self.list_music()?;
        println!();
        print!("song name or number> ");
        io::stdout().flush()?;
        let mut selection = String::new();
        io::stdin().read_line(&mut selection)?;
        let selection = selection.trim();
        if selection.is_empty() {
            return Ok(());
        }
        self.open_music(selection)?;
        wait_for_enter()
    }

    fn music_file_by_name(&self, name: &str) -> io::Result<PathBuf> {
        if name.is_empty() {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "song name is required",
            ));
        }

        let direct = self.music_root.join(name);
        if direct.is_file() {
            return Ok(direct);
        }

        let entries = self.music_entries()?;
        if let Ok(number) = name.parse::<usize>() {
            if number > 0 {
                return entries
                    .get(number - 1)
                    .map(|entry| entry.path())
                    .ok_or_else(|| {
                        io::Error::new(io::ErrorKind::NotFound, "song number is not in the list")
                    });
            }
        }
        entries
            .into_iter()
            .map(|entry| entry.path())
            .find(|path| {
                path.file_name()
                    .map(|file_name| file_name.to_string_lossy().contains(name))
                    .unwrap_or(false)
            })
            .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "song not found in Rasa Music"))
    }

    fn rm(&self, args: &[String]) -> io::Result<()> {
        require_args(args, "rm [-r] <path>...")?;
        let recursive = args
            .iter()
            .any(|arg| arg == "-r" || arg == "-rf" || arg == "-fr");
        let paths = args
            .iter()
            .filter(|arg| !arg.starts_with('-'))
            .collect::<Vec<_>>();
        require_args_refs(&paths, "rm [-r] <path>...")?;

        for arg in paths {
            let path = self.resolve(arg);
            if path.is_dir() {
                if recursive {
                    fs::remove_dir_all(path)?;
                } else {
                    fs::remove_dir(path)?;
                }
            } else {
                fs::remove_file(path)?;
            }
        }
        Ok(())
    }

    fn cp(&self, args: &[String]) -> io::Result<()> {
        let recursive = args.iter().any(|arg| arg == "-r" || arg == "-R");
        let paths = args
            .iter()
            .filter(|arg| !arg.starts_with('-'))
            .collect::<Vec<_>>();
        if paths.len() != 2 {
            return usage("cp [-r] <from> <to>");
        }

        let from = self.resolve(paths[0]);
        let to = self.resolve(paths[1]);
        if from.is_dir() {
            if !recursive {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidInput,
                    "directory copy needs -r",
                ));
            }
            copy_dir_recursive(&from, &to)?;
        } else {
            fs::copy(from, to)?;
        }
        Ok(())
    }

    fn mv(&self, args: &[String]) -> io::Result<()> {
        if args.len() != 2 {
            return usage("mv <from> <to>");
        }
        fs::rename(self.resolve(&args[0]), self.resolve(&args[1]))
    }

    fn tree(&self, args: &[String]) -> io::Result<()> {
        let path = self.resolve(args.first().map(String::as_str).unwrap_or("."));
        let depth = args
            .get(1)
            .and_then(|value| value.parse::<usize>().ok())
            .unwrap_or(2);
        println!("{}", path.display());
        print_tree(&path, 0, depth)
    }

    fn find(&self, args: &[String]) -> io::Result<()> {
        require_args(args, "find <name> [path]")?;
        let needle = &args[0];
        let root = self.resolve(args.get(1).map(String::as_str).unwrap_or("."));
        find_matching(&root, needle)
    }

    fn date(&self) -> io::Result<()> {
        let seconds = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(io::Error::other)?
            .as_secs();
        println!("unix time: {seconds}");
        Ok(())
    }

    fn uname(&self) -> io::Result<()> {
        println!("Rasa OS {VERSION} rust-shell {}", env::consts::OS);
        Ok(())
    }

    fn sysinfo(&self) -> io::Result<()> {
        println!("{BOLD}Rasa OS{RESET}       {VERSION}");
        println!("{BOLD}Host OS{RESET}       {}", env::consts::OS);
        println!("{BOLD}Arch{RESET}          {}", env::consts::ARCH);
        println!("{BOLD}Current dir{RESET}   {}", self.cwd.display());
        println!("{BOLD}Storage{RESET}       {}", self.storage_root.display());
        println!("{BOLD}Music{RESET}         {}", self.music_root.display());
        println!(
            "{BOLD}User{RESET}          {}",
            env::var("USER")
                .or_else(|_| env::var("USERNAME"))
                .unwrap_or_else(|_| "unknown".to_string())
        );
        Ok(())
    }

    fn syscall_command(&self, args: &[String]) -> io::Result<()> {
        match args.first().map(String::as_str) {
            None => syscall::repl(),
            Some("help") => {
                syscall::help();
                Ok(())
            }
            Some("list") => {
                syscall::list();
                Ok(())
            }
            Some("call") => {
                if args.len() < 2 {
                    return usage("syscall call <name> [args]");
                }
                syscall::call(&args[1], &args[2..], &self.cwd)
            }
            Some(name) => syscall::call(name, &args[1..], &self.cwd),
        }
    }

    fn run_host(&self, args: &[String]) -> io::Result<()> {
        require_args(args, "run <program> [args]")?;
        let status = Command::new(&args[0])
            .args(&args[1..])
            .current_dir(&self.cwd)
            .status()?;
        if !status.success() {
            eprintln!("{YELLOW}program exited with status:{RESET} {status}");
        }
        Ok(())
    }

    fn vim(&self, args: &[String]) -> io::Result<()> {
        require_args(args, "vi|vim <file>")?;
        let path = format!("{}", self.resolve(&args[0]).display());

        let bundled = rasa_share_dir()
            .join("vendor")
            .join("neovim")
            .join("bin")
            .join(if cfg!(windows) { "nvim.exe" } else { "nvim" });

        let mut command = if bundled.is_file() {
            Command::new(&bundled)
        } else {
            Command::new(if cfg!(windows) { "nvim.exe" } else { "nvim" })
        };
        let status = command
            .arg(&path)
            .current_dir(&self.cwd)
            .status()
            .or_else(|_| Command::new("vim").arg(&path).status())
            .or_else(|_| {
                if cfg!(windows) {
                    Command::new("notepad").arg(&path).status()
                } else {
                    Command::new("vi").arg(&path).status()
                }
            })?;

        if !status.success() {
            eprintln!("{YELLOW}vim exited with status:{RESET} {status}");
        }
        println!("{DIM}(done editing {path}){RESET}");
        Ok(())
    }

    fn resolve(&self, path: &str) -> PathBuf {
        let path = expand_home(path);
        if path.is_absolute() {
            path
        } else {
            self.cwd.join(path)
        }
    }

    fn short_cwd(&self) -> PathBuf {
        if let Some(home) = home_dir() {
            if let Ok(rest) = self.cwd.strip_prefix(home) {
                if rest.as_os_str().is_empty() {
                    return PathBuf::from("~");
                }
                return Path::new("~").join(rest);
            }
        }
        self.cwd.clone()
    }
}

fn main() {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.as_slice() == ["os"] {
        match RasaOs::new() {
            Ok(mut os) => os.boot(),
            Err(error) => {
                eprintln!("failed to boot Rasa OS: {error}");
                std::process::exit(1);
            }
        }
        return;
    }

    if args.first().map(String::as_str) == Some("etc") {
        if let Err(error) = etc::handle(&args[1..]) {
            eprintln!("etc: {error}");
            std::process::exit(1);
        }
        return;
    }

    println!("{CYAN}{BOLD}Rasa CLI {VERSION}{RESET}");
    println!("Usage: rasa os");
    println!("       rasa etc list|status|show|diff|apply|danger|auto|sync");
}

fn select_menu(title: &str, subtitle: &str, items: &[&str]) -> io::Result<Option<usize>> {
    let mut terminal = io::stdout();
    let mut selected = 0usize;

    enable_raw_mode()?;
    terminal.execute(EnterAlternateScreen)?;
    terminal.execute(Hide)?;

    let result = loop {
        draw_menu(&mut terminal, title, subtitle, items, selected)?;

        if let Event::Key(event) = read()? {
            match event.code {
                KeyCode::Up => {
                    selected = selected
                        .checked_sub(1)
                        .unwrap_or(items.len().saturating_sub(1));
                }
                KeyCode::Down => {
                    selected = (selected + 1) % items.len();
                }
                KeyCode::Enter => break Ok(Some(selected)),
                KeyCode::Esc | KeyCode::Char('q') | KeyCode::Char('Q') => break Ok(None),
                _ => {}
            }
        }
    };

    terminal.execute(Show)?;
    terminal.execute(LeaveAlternateScreen)?;
    disable_raw_mode()?;
    result
}

fn draw_menu(
    terminal: &mut io::Stdout,
    title: &str,
    subtitle: &str,
    items: &[&str],
    selected: usize,
) -> io::Result<()> {
    const MAX_VISIBLE_ITEMS: usize = 4;
    let (width, height) = size()?;
    let box_width = 54u16.min(width.saturating_sub(4)).max(30);
    let visible_count = items.len().min(MAX_VISIBLE_ITEMS);
    let box_height = (visible_count as u16 + 6)
        .min(height.saturating_sub(2))
        .max(8);
    let start_x = width.saturating_sub(box_width) / 2;
    let start_y = height.saturating_sub(box_height) / 2;
    let first_visible = selected
        .saturating_sub(MAX_VISIBLE_ITEMS.saturating_sub(1))
        .min(items.len().saturating_sub(visible_count));

    terminal.execute(Clear(ClearType::All))?;
    terminal.execute(MoveTo(start_x, start_y))?;
    write!(
        terminal,
        "{MAGENTA}┌{}┐{RESET}",
        "─".repeat(box_width as usize - 2)
    )?;

    terminal.execute(MoveTo(start_x, start_y + 1))?;
    write_box_line(terminal, box_width, title, true)?;

    terminal.execute(MoveTo(start_x, start_y + 2))?;
    write_box_line(terminal, box_width, subtitle, false)?;

    terminal.execute(MoveTo(start_x, start_y + 3))?;
    write!(
        terminal,
        "{MAGENTA}├{}┤{RESET}",
        "─".repeat(box_width as usize - 2)
    )?;

    for (row, (index, item)) in items
        .iter()
        .enumerate()
        .skip(first_visible)
        .take(visible_count)
        .enumerate()
    {
        terminal.execute(MoveTo(start_x, start_y + 4 + row as u16))?;
        let marker = if index == selected { "▶" } else { " " };
        let up = if row == 0 && first_visible > 0 {
            "↑ "
        } else {
            "  "
        };
        let down = if row + 1 == visible_count && first_visible + visible_count < items.len() {
            " ↓"
        } else {
            "  "
        };
        let line = format!("{up}{marker} {item}{down}");
        if index == selected {
            write_box_line(terminal, box_width, &format!("{GREEN}{line}{RESET}"), false)?;
        } else {
            write_box_line(terminal, box_width, &line, false)?;
        }
    }

    terminal.execute(MoveTo(start_x, start_y + box_height - 1))?;
    write!(
        terminal,
        "{MAGENTA}└{}┘{RESET}",
        "─".repeat(box_width as usize - 2)
    )?;
    terminal.flush()
}

fn write_box_line(terminal: &mut io::Stdout, width: u16, text: &str, bold: bool) -> io::Result<()> {
    let visible_len = strip_ansi_len(text);
    let content_width = width as usize - 4;
    let padding = content_width.saturating_sub(visible_len);
    let right = " ".repeat(padding);

    if bold {
        write!(
            terminal,
            "{MAGENTA}│{RESET} {BOLD}{text}{RESET}{right} {MAGENTA}│{RESET}"
        )
    } else {
        write!(
            terminal,
            "{MAGENTA}│{RESET} {text}{right} {MAGENTA}│{RESET}"
        )
    }
}

fn head(title: &str) {
    println!(
        "\n{BOLD}{CYAN}── {title}{RESET} {DIM}{}{RESET}",
        "─".repeat(42usize.saturating_sub(title.chars().count().min(42)))
    );
}

fn row(command: &str, description: &str) {
    let visible = strip_ansi_len(command);
    let padding = 36usize.saturating_sub(visible);
    println!("{GREEN}{command}{RESET}{} {DIM}{description}{RESET}", " ".repeat(padding));
}

fn strip_ansi_len(text: &str) -> usize {
    let mut count = 0;
    let mut in_escape = false;

    for character in text.chars() {
        if in_escape {
            if character == 'm' {
                in_escape = false;
            }
            continue;
        }

        if character == '\x1b' {
            in_escape = true;
        } else {
            count += 1;
        }
    }

    count
}

fn wait_for_enter() -> io::Result<()> {
    println!();
    print!("{DIM}press Enter to continue...{RESET}");
    io::stdout().flush()?;
    let mut line = String::new();
    io::stdin().read_line(&mut line)?;
    Ok(())
}

fn clear_terminal() -> io::Result<()> {
    if cfg!(windows) {
        let status = Command::new("cmd").args(["/C", "cls"]).status();
        if status.is_ok() {
            return Ok(());
        }
    }

    print!("\x1B[2J\x1B[1;1H");
    io::stdout().flush()
}

fn type_text(text: &str, delay: Duration) {
    for character in text.chars() {
        print!("{character}");
        let _ = io::stdout().flush();
        thread::sleep(delay);
    }
}

fn strip_host_syscall(line: &str) -> Option<String> {
    let words = split_words(line);
    let (last, rest) = words.split_last()?;
    if last == "-cas" && !rest.is_empty() {
        Some(rest.join(" "))
    } else {
        None
    }
}

fn split_words(line: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut current = String::new();
    let mut in_quotes = false;
    let mut escaped = false;

    for character in line.chars() {
        if escaped {
            // A backslash is a path separator on Windows. Only consume it as
            // shell escaping when it actually escapes whitespace, a quote, or
            // another backslash (the forms produced by Unix terminal drops).
            if matches!(character, ' ' | '\t' | '"' | '\\') {
                current.push(character);
            } else {
                current.push('\\');
                current.push(character);
            }
            escaped = false;
            continue;
        }

        match character {
            '\\' => escaped = true,
            '"' | '\'' => in_quotes = !in_quotes,
            ' ' | '\t' if !in_quotes => {
                if !current.is_empty() {
                    words.push(std::mem::take(&mut current));
                }
            }
            _ => current.push(character),
        }
    }

    if escaped {
        current.push('\\');
    }

    if !current.is_empty() {
        words.push(current);
    }

    words
}

fn dropped_path(input: &str) -> PathBuf {
    let mut value = input.trim();
    if value.len() >= 2
        && ((value.starts_with('"') && value.ends_with('"'))
            || (value.starts_with('\'') && value.ends_with('\'')))
    {
        value = &value[1..value.len() - 1];
    }

    let mut value = if let Some(rest) = value.strip_prefix("file://localhost/") {
        format!("/{rest}")
    } else if let Some(rest) = value.strip_prefix("file:///") {
        format!("/{rest}")
    } else {
        value.to_string()
    };

    value = percent_decode(&value);
    if cfg!(windows)
        && value.len() >= 3
        && value.starts_with('/')
        && value.as_bytes()[1].is_ascii_alphabetic()
        && value.as_bytes()[2] == b':'
    {
        value.remove(0);
    }

    PathBuf::from(unescape_unix_drop(&value))
}

fn percent_decode(value: &str) -> String {
    let bytes = value.as_bytes();
    let mut output = Vec::with_capacity(bytes.len());
    let mut index = 0;

    while index < bytes.len() {
        if bytes[index] == b'%' && index + 2 < bytes.len() {
            if let (Some(high), Some(low)) =
                (hex_value(bytes[index + 1]), hex_value(bytes[index + 2]))
            {
                output.push(high << 4 | low);
                index += 3;
                continue;
            }
        }

        output.push(bytes[index]);
        index += 1;
    }

    String::from_utf8(output).unwrap_or_else(|_| value.to_string())
}

fn hex_value(byte: u8) -> Option<u8> {
    match byte {
        b'0'..=b'9' => Some(byte - b'0'),
        b'a'..=b'f' => Some(byte - b'a' + 10),
        b'A'..=b'F' => Some(byte - b'A' + 10),
        _ => None,
    }
}

fn unescape_unix_drop(value: &str) -> String {
    if cfg!(windows) {
        return value.to_string();
    }

    let mut output = String::new();
    let mut characters = value.chars();
    while let Some(character) = characters.next() {
        if character == '\\' {
            match characters.next() {
                Some(next @ (' ' | '\t' | '"' | '\\')) => output.push(next),
                Some(next) => {
                    output.push('\\');
                    output.push(next);
                }
                None => output.push('\\'),
            }
        } else {
            output.push(character);
        }
    }
    output
}

fn expand_home(path: &str) -> PathBuf {
    if path == "~" {
        if let Some(home) = home_dir() {
            return home;
        }
    }

    if let Some(rest) = path.strip_prefix("~/") {
        if let Some(home) = home_dir() {
            return home.join(rest);
        }
    }

    PathBuf::from(path)
}

fn home_dir() -> Option<PathBuf> {
    env::var_os("HOME")
        .map(PathBuf::from)
        .or_else(|| env::var_os("USERPROFILE").map(PathBuf::from))
        .or_else(|| {
            let drive = env::var_os("HOMEDRIVE")?;
            let path = env::var_os("HOMEPATH")?;
            let mut home = PathBuf::from(drive);
            home.push(path);
            Some(home)
        })
}

fn rasa_storage_dir() -> PathBuf {
    if let Ok(path) = env::var("RASA_OS_HOME") {
        return PathBuf::from(path);
    }

    if cfg!(windows) {
        if let Some(app_data) = env::var_os("APPDATA") {
            return PathBuf::from(app_data).join("RasaOS");
        }
    }

    if cfg!(target_os = "macos") {
        if let Some(home) = home_dir() {
            return home
                .join("Library")
                .join("Application Support")
                .join("RasaOS");
        }
    }

    home_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join(".local")
        .join("share")
        .join("rasa-os")
}

/// Root directory that owns `etc/`, `vendor/neovim/`, `share/` for the
/// installed binary. Priority: RASA_OS_HOME -> next to the executable
/// (`$prefix/share/rasa`) -> the source tree (dev builds).
fn rasa_share_dir() -> PathBuf {
    if let Ok(path) = env::var("RASA_OS_HOME") {
        if !path.is_empty() {
            return PathBuf::from(path);
        }
    }

    if let Ok(exe) = env::current_exe() {
        if let Some(bin) = exe.parent() {
            // Installed layout: <prefix>/bin/rasa + <prefix>/share/rasa
            if let Some(prefix) = bin.parent() {
                let share = prefix.join("share").join("rasa");
                if share.join("etc").is_dir() || share.join("vendor").is_dir() {
                    return share;
                }
            }
            // Flat layout: rasa.exe sits next to etc/ and vendor/
            let flat = bin.join("etc");
            if flat.is_dir() {
                return bin.to_path_buf();
            }
        }
    }

    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

fn unique_destination(root: &Path, file_name: &std::ffi::OsStr) -> PathBuf {
    let original = Path::new(file_name);
    let stem = original
        .file_stem()
        .unwrap_or(file_name)
        .to_string_lossy()
        .to_string();
    let extension = original
        .extension()
        .map(|extension| format!(".{}", extension.to_string_lossy()))
        .unwrap_or_default();

    let mut candidate = root.join(file_name);
    let mut counter = 1;
    while candidate.exists() {
        candidate = root.join(format!("{stem}-{counter}{extension}"));
        counter += 1;
    }
    candidate
}

fn human_size(bytes: u64) -> String {
    let units = ["B", "KB", "MB", "GB"];
    let mut size = bytes as f64;
    let mut unit = 0;

    while size >= 1024.0 && unit < units.len() - 1 {
        size /= 1024.0;
        unit += 1;
    }

    if unit == 0 {
        format!("{} {}", bytes, units[unit])
    } else {
        format!("{size:.1} {}", units[unit])
    }
}

/// Long listing entry for `ls -l`: `<permissions> <size> <colored name>`.
fn format_long_entry(metadata: &fs::Metadata, name: &str) -> String {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mode = metadata.permissions().mode();
        let kind = if metadata.is_dir() { 'd' } else { '-' };
        let perm = format!("{kind}{}{}{}", rwx(mode >> 6), rwx(mode >> 3), rwx(mode));
        let color = if metadata.is_dir() { BLUE } else if is_executable(metadata) { GREEN } else { "" };
        format!("{perm} {:>10}  {color}{name}{RESET}", human_size(metadata.len()))
    }

    #[cfg(not(unix))]
    {
        let _ = metadata;
        format!("{:>10}  {name}", human_size(metadata.len()))
    }
}

/// Map permission bits 0..8 to an rwx triple.
#[cfg(unix)]
fn rwx(bits: u32) -> &'static str {
    match bits & 0o7 {
        7 => "rwx",
        6 => "rw-",
        5 => "r-x",
        4 => "r--",
        3 => "-wx",
        2 => "-w-",
        1 => "--x",
        _ => "---",
    }
}

fn copy_dir_recursive(from: &Path, to: &Path) -> io::Result<()> {
    fs::create_dir_all(to)?;
    for entry in fs::read_dir(from)? {
        let entry = entry?;
        let child_from = entry.path();
        let child_to = to.join(entry.file_name());
        if child_from.is_dir() {
            copy_dir_recursive(&child_from, &child_to)?;
        } else {
            fs::copy(child_from, child_to)?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shell_parser_keeps_windows_path_separators() {
        let words = split_words(r#"music add C:\Users\Rasa\song.mp3"#);
        assert_eq!(words, vec!["music", "add", r"C:\Users\Rasa\song.mp3"]);
    }

    #[test]
    fn shell_parser_unescapes_unix_dropped_spaces() {
        let words = split_words(r"music add /tmp/My\ Song.mp3");
        assert_eq!(words, vec!["music", "add", "/tmp/My Song.mp3"]);
    }

    #[test]
    fn dropped_path_decodes_unicode_file_urls() {
        assert_eq!(
            dropped_path("file:///tmp/%D9%85%D9%88%D8%B3%DB%8C%D9%82%DB%8C.mp3"),
            PathBuf::from("/tmp/موسیقی.mp3")
        );
    }

    #[test]
    fn dropped_path_unescapes_unix_terminal_input() {
        assert_eq!(
            dropped_path(r#"'/tmp/My\ Song.mp3'"#),
            PathBuf::from("/tmp/My Song.mp3")
        );
    }
}

fn print_tree(path: &Path, level: usize, max_depth: usize) -> io::Result<()> {
    if level >= max_depth || !path.is_dir() {
        return Ok(());
    }

    let mut entries = fs::read_dir(path)?.collect::<Result<Vec<_>, _>>()?;
    entries.sort_by_key(|entry| entry.file_name());

    for entry in entries {
        let child = entry.path();
        let metadata = entry.metadata()?;
        let prefix = "  ".repeat(level + 1);
        let name = entry.file_name().to_string_lossy().to_string();
        if metadata.is_dir() {
            println!("{prefix}{BLUE}{name}/{RESET}");
            print_tree(&child, level + 1, max_depth)?;
        } else {
            println!("{prefix}{name}");
        }
    }
    Ok(())
}

fn find_matching(path: &Path, needle: &str) -> io::Result<()> {
    if !path.is_dir() {
        return Ok(());
    }

    for entry in fs::read_dir(path)? {
        let entry = entry?;
        let child = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();
        if name.contains(needle) {
            println!("{}", child.display());
        }
        if child.is_dir() {
            find_matching(&child, needle)?;
        }
    }
    Ok(())
}

fn is_executable(metadata: &fs::Metadata) -> bool {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        metadata.permissions().mode() & 0o111 != 0
    }

    #[cfg(not(unix))]
    {
        let _ = metadata;
        false
    }
}

fn require_args(args: &[String], message: &str) -> io::Result<()> {
    if args.is_empty() {
        usage(message)
    } else {
        Ok(())
    }
}

fn require_args_refs(args: &[&String], message: &str) -> io::Result<()> {
    if args.is_empty() {
        usage(message)
    } else {
        Ok(())
    }
}

fn usage<T>(message: &str) -> io::Result<T> {
    Err(io::Error::new(
        io::ErrorKind::InvalidInput,
        format!("usage: {message}"),
    ))
}
