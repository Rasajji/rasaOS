use std::env;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use std::process::Command;

const ETC_ENV: &str = "RASA_ETC_DIR";

fn etc_root() -> PathBuf {
    if let Ok(dir) = env::var(ETC_ENV) {
        return PathBuf::from(dir);
    }
    crate::rasa_share_dir().join("etc")
}

fn host_etc() -> &'static str {
    if cfg!(windows) {
        "C:\\Windows\\System32\\drivers\\etc"
    } else {
        "/etc"
    }
}

fn rel_is_ignored(rel: &Path) -> bool {
    let name = rel
        .file_name()
        .map(|value| value.to_string_lossy())
        .unwrap_or_default();
    name == ".DS_Store" || name.starts_with('.') && name != ".profile"
}

fn collect_files(base: &Path, dir: &Path, out: &mut Vec<PathBuf>) -> io::Result<()> {
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_dir() {
            collect_files(base, &path, out)?;
        } else {
            let rel = path
                .strip_prefix(base)
                .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "etc path escape"))?
                .to_path_buf();
            if !rel_is_ignored(&rel) {
                out.push(rel);
            }
        }
    }
    Ok(())
}

fn files() -> io::Result<Vec<PathBuf>> {
    let base = etc_root();
    let mut out = Vec::new();
    collect_files(&base, &base, &mut out)?;
    out.sort();
    Ok(out)
}

fn host_path(rel: &Path) -> PathBuf {
    let mut path = PathBuf::from(host_etc());
    path.push(rel);
    path
}

fn is_dangerous(rel: &Path) -> bool {
    let value = rel.to_string_lossy();
    let value = value.replace('\\', "/");
    let flows = [
        "passwd",
        "shadow",
        "group",
        "sudoers",
        "sudoers.d/",
        "fstab",
        "crontab",
        "cron.d/",
    ];
    flows.iter().any(|flow| {
        value == *flow || value.starts_with(&format!("{flow}/")) || value.ends_with(&format!("{flow}"))
    })
}

fn running_as_root() -> bool {
    match Command::new("id").arg("-u").output() {
        Ok(output) => String::from_utf8_lossy(&output.stdout).trim() == "0",
        Err(_) => false,
    }
}

fn shq(value: &str) -> String {
    format!("'{}'", value.replace('\'', "'\\''"))
}

fn elevated() -> Option<&'static str> {
    if running_as_root() {
        None
    } else {
        Some("sudo")
    }
}

fn run(program: &str, args: &[&str]) -> io::Result<bool> {
    let status = Command::new(program).args(args).status()?;
    Ok(status.success())
}

fn run_elevated(program: &str, args: &[&str]) -> io::Result<bool> {
    match elevated() {
        None => run(program, args),
        Some(sudo) => Command::new(sudo)
            .arg(program)
            .args(args)
            .status()
            .map(|status| status.success()),
    }
}

fn run_sh(script: &str) -> io::Result<bool> {
    match elevated() {
        None => run("sh", &["-c", script]),
        Some(sudo) => Command::new(sudo)
            .args(["sh", "-c"])
            .arg(script)
            .status()
            .map(|status| status.success()),
    }
}

fn mode_of(path: &Path) -> u32 {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        path.metadata()
            .map(|meta| meta.permissions().mode() & 0o7777)
            .unwrap_or(0o644)
    }
    #[cfg(not(unix))]
    {
        let _ = path;
        0o644
    }
}

fn now_stamp() -> String {
    let seconds = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or(0);
    seconds.to_string()
}

fn content_differs(rel: &Path) -> io::Result<bool> {
    let bundled = fs::read(etc_root().join(rel))?;
    match fs::read(host_path(rel)) {
        Ok(host) => Ok(host != bundled),
        Err(_) => Ok(true),
    }
}

fn binary_path() -> PathBuf {
    env::current_exe().unwrap_or_else(|_| PathBuf::from("rasa"))
}

pub fn help() {
    println!("  \u{1b}[32metc list\u{1b}[0m                  bundled config files");
    println!("  \u{1b}[32metc status [file...]\u{1b}[0m      bundled = MISSING / SAME / DIFF");
    println!("  \u{1b}[32metc show <file>\u{1b}[0m           print bundled content");
    println!("  \u{1b}[32metc diff  [file...]\u{1b}[0m       unified diff vs host");
    println!("  \u{1b}[32metc apply [file...] [--force]\u{1b}[0m   write bundled files to /etc (sudo, backup, atomic)");
    println!("  \u{1b}[32metc danger\u{1b}[0m                files gated behind --force");
    println!("  \u{1b}[32metc auto on|off|status\u{1b}[0m    boot-time auto sync (systemd / launchd)");
    println!("  \u{1b}[32metc sync\u{1b}[0m                  non-interactive apply-all (used at boot)");
}

pub fn handle(args: &[String]) -> io::Result<()> {
    let Some(subcommand) = args.first().map(String::as_str) else {
        return status_summary();
    };
    let rest = &args[1..];

    match subcommand {
        "list" => cmd_list(),
        "status" => cmd_status(rest),
        "show" => cmd_show(rest),
        "diff" => cmd_diff(rest),
        "apply" => cmd_apply(rest),
        "danger" => cmd_danger(),
        "auto" => cmd_auto(rest),
        "sync" => cmd_sync(),
        other => Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!(
                "unknown etc subcommand: {other}\ntry: etc list | status | show | diff | apply | danger | auto | sync"
            ),
        )),
    }
}

fn cmd_list() -> io::Result<()> {
    let all = files()?;
    if all.is_empty() {
        println!("(no bundled config files)");
        return Ok(());
    }
    for rel in &all {
        let marker = if is_dangerous(rel) { "!" } else { " " };
        println!("{marker} {}", rel.display());
    }
    println!();
    println!("{} files ({})", all.len(), etc_root().display());
    println!("! = needs `etc apply --force`");
    Ok(())
}

fn cmd_status(args: &[String]) -> io::Result<()> {
    let mut entries = status_targets(args)?;
    let mut changed = 0usize;
    let mut installed = 0usize;
    for rel in &mut entries {
        let state = match content_differs(rel) {
            Ok(false) => "SAME",
            Ok(true) => {
                changed += 1;
                "DIFF"
            }
            Err(_) => {
                changed += 1;
                "DIFF"
            }
        };
        if fs::metadata(host_path(rel)).is_ok() {
            installed += 1;
        }
        let danger = if is_dangerous(rel) { " (dangerous)" } else { "" };
        println!(
            "{state:>5}  {}{}",
            rel.display(),
            if state == "SAME" { "" } else { danger }
        );
    }
    println!();
    println!(
        "{installed}/{} present on host, {changed} differ from host",
        entries.len()
    );
    Ok(())
}

fn status_targets(args: &[String]) -> io::Result<Vec<PathBuf>> {
    if args.is_empty() {
        return files();
    }
    let base = etc_root();
    let mut out = Vec::new();
    for arg in args {
        let rel = PathBuf::from(arg);
        let path = base.join(&rel);
        if !path.is_file() {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("bundled config not found: {arg}"),
            ));
        }
        out.push(rel);
    }
    Ok(out)
}

fn cmd_show(args: &[String]) -> io::Result<()> {
    if args.is_empty() {
        return usage_msg("etc show <file>");
    }
    let path = etc_root().join(&args[0]);
    if !path.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("bundled config not found: {}", args[0]),
        ));
    }
    print!("{}", fs::read_to_string(&path)?);
    Ok(())
}

fn cmd_diff(args: &[String]) -> io::Result<()> {
    let targets = status_targets(args)?;
    for rel in &targets {
        let host = host_path(rel);
        println!("--- /etc/{}  (host)", rel.display());
        println!("+++ {}  (bundled)", rel.display());
        if !host.exists() {
            println!("(only in bundled etc)");
            continue;
        }
        let status = Command::new("diff")
            .arg("-u")
            .arg(&host)
            .arg(etc_root().join(rel))
            .status()?;
        if status.success() {
            print!("no difference\n");
        }
    }
    Ok(())
}

fn cmd_danger() -> io::Result<()> {
    let all = files()?;
    let dangerous: Vec<_> = all.into_iter().filter(|rel| is_dangerous(rel)).collect();
    if dangerous.is_empty() {
        println!("(no dangerous files)");
        return Ok(());
    }
    for rel in &dangerous {
        println!("{}", rel.display());
    }
    println!();
    println!(
        "these keep the system identity (users/passwords/mounts/sudo) and are only applied with `etc apply --force`"
    );
    Ok(())
}

fn cmd_apply(args: &[String]) -> io::Result<()> {
    let force = args.iter().any(|arg| arg == "--force");
    let names: Vec<String> = args
        .iter()
        .filter(|arg| arg.as_str() != "--force")
        .cloned()
        .collect();
    let targets = if names.is_empty() {
        files()?
    } else {
        status_targets(&names)?
    };

    println!("Rasa etc -> {} (sudo)", host_etc());
    let mut applied = 0usize;
    let mut skipped = 0usize;
    let mut unchanged = 0usize;
    for rel in &targets {
        match apply_one(rel, force) {
            Ok(ApplyOutcome::Applied) => {
                applied += 1;
                println!("  applied  {}", rel.display());
            }
            Ok(ApplyOutcome::Unchanged) => {
                unchanged += 1;
                println!("  same     {}", rel.display());
            }
            Ok(ApplyOutcome::DangerSkipped) => {
                skipped += 1;
                println!(
                    "  skip     {} (dangerous, use --force)",
                    rel.display()
                );
            }
            Err(error) => {
                skipped += 1;
                eprintln!("  error    {}: {error}", rel.display());
            }
        }
    }
    println!();
    println!(
        "{applied} applied, {unchanged} already in sync, {skipped} skipped"
    );
    Ok(())
}

enum ApplyOutcome {
    Applied,
    Unchanged,
    DangerSkipped,
}

fn apply_one(rel: &Path, force: bool) -> io::Result<ApplyOutcome> {
    let src = etc_root().join(rel);
    let dst = host_path(rel);
    let bundled = fs::read(&src)?;
    if let Ok(host) = fs::read(&dst) {
        if host == bundled {
            return Ok(ApplyOutcome::Unchanged);
        }
    }
    if is_dangerous(rel) && !force {
        return Ok(ApplyOutcome::DangerSkipped);
    }

    if let Some(parent) = dst.parent() {
        run_sh(&format!("mkdir -p {}", shq(&parent.to_string_lossy())))?;
    }

    if dst.exists() {
        let backup = format!(
            "{}",
            dst.with_extension(format!("rasa-bak-{}", now_stamp())).display()
        );
        let _ = run_sh(&format!("cp -p {} {}", shq(&dst.to_string_lossy()), shq(&backup)));
    }

    let tmp = dst.with_extension(format!("rasa-tmp-{}", now_stamp()));
    fs::write(&tmp, &bundled)?;

    let mode = if dst.exists() {
        mode_of(&dst)
    } else {
        mode_of(&src)
    };
    let mode = format!("{mode:o}");
    let script = format!(
        "install -o root -g root -m {mode} {} {} || cat {} > {}",
        shq(&tmp.to_string_lossy()),
        shq(&dst.to_string_lossy()),
        shq(&tmp.to_string_lossy()),
        shq(&dst.to_string_lossy())
    );
    let ok = run_sh(&script)?;
    let _ = fs::remove_file(&tmp);
    if !ok {
        return Err(io::Error::other(format!(
            "failed to write {} (sudo required?)",
            dst.display()
        )));
    }

    post_apply(rel)?;

    Ok(ApplyOutcome::Applied)
}

fn post_apply(rel: &Path) -> io::Result<()> {
    let name = rel.to_string_lossy().replace('\\', "/");
    if name == "hostname" {
        if let Ok(content) = fs::read_to_string(etc_root().join(rel)) {
            let host = content.trim();
            if !host.is_empty() {
                if cfg!(target_os = "macos") {
                    let _ = run_elevated("scutil", &["--set", "HostName", host]);
                    let _ = run_elevated("scutil", &["--set", "LocalHostName", host]);
                } else {
                    let _ = run_elevated("hostnamectl", &["set-hostname", host]);
                }
            }
        }
    } else if name.starts_with("sysctl.d/") {
        if cfg!(target_os = "macos") {
            let _ = run_elevated("sysctl", &["-f", "/etc/sysctl.conf"]);
        } else {
            let _ = run_elevated("sysctl", &["--system"]);
        }
    } else if name.starts_with("systemd/system/") && name.ends_with(".service") {
        if !cfg!(target_os = "macos") {
            let _ = run_elevated("systemctl", &["daemon-reload"]);
        }
    } else if name == "resolv.conf" {
        println!(
            "  note: /etc/resolv.conf may be managed by systemd-resolved; a backup was kept"
        );
    }
    Ok(())
}

fn cmd_sync() -> io::Result<()> {
    let all = files()?;
    let mut applied = 0usize;
    let mut skipped = 0usize;
    for rel in &all {
        if is_dangerous(rel) {
            skipped += 1;
            continue;
        }
        match apply_one(rel, false) {
            Ok(ApplyOutcome::Applied) => {
                applied += 1;
                println!("applied  {}", rel.display());
            }
            Ok(_) => {}
            Err(error) => {
                skipped += 1;
                eprintln!("error    {}: {error}", rel.display());
            }
        }
    }
    println!("rasa etc sync: {applied} applied, {skipped} skipped");
    Ok(())
}

fn cmd_auto(args: &[String]) -> io::Result<()> {
    let Some(action) = args.first().map(String::as_str) else {
        return usage_msg("etc auto on|off|status");
    };
    match action {
        "on" => auto_enable(),
        "off" => auto_disable(),
        "status" => auto_status(),
        other => Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("unknown auto action: {other}"),
        )),
    }
}

fn auto_enable() -> io::Result<()> {
    let exe = binary_path();
    if !exe.is_file() {
        return Err(io::Error::other(format!(
            "binary not found for boot service: {}",
            exe.display()
        )));
    }
    let exe_arg = exe.to_string_lossy().to_string();

    if cfg!(target_os = "macos") {
        let plist = format!(
            r#"<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>io.rasa.etcsync</string>
  <key>ProgramArguments</key>
  <array>
    <string>{exe_arg}</string>
    <string>etc</string>
    <string>sync</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
</dict>
</plist>
"#
        );
        let target = PathBuf::from("/Library/LaunchDaemons/io.rasa.etcsync.plist");
        let mode = mode_of(&target);
        fs::write(&target, plist)?;
        let _ = run_elevated("chown", &["root:wheel", &target.to_string_lossy()]);
        let _ = run_elevated("chmod", &[&format!("{mode:o}"), &target.to_string_lossy()]);
        let ok = run_elevated("launchctl", &["load", "-w", &target.to_string_lossy()])?
            || run_elevated(
                "launchctl",
                &["bootstrap", "system", &target.to_string_lossy()],
            )?;
        if ok {
            println!("launchd service installed: {}", target.display());
        } else {
            eprintln!("launchctl load failed; service file remains at {}", target.display());
        }
    } else {
        let unit = format!(
            "[Unit]\nDescription=Rasa OS Etc Auto-Sync\nAfter=network.target\n\n[Service]\nType=oneshot\nExecStart={exe_arg} etc sync\nRemainAfterExit=yes\n\n[Install]\nWantedBy=multi-user.target\n"
        );
        let target = PathBuf::from("/etc/systemd/system/rasa-etc-sync.service");
        let mode = mode_of(&target);
        fs::write(&target, unit)?;
        let _ = run_elevated("chown", &["root:root", &target.to_string_lossy()]);
        let _ = run_elevated("chmod", &[&format!("{mode:o}"), &target.to_string_lossy()]);
        let _ = run_elevated("systemctl", &["daemon-reload"]);
        let enabled = run_elevated("systemctl", &["enable", "rasa-etc-sync.service"])?;
        if enabled {
            println!("systemd service installed + enabled: {}", target.display());
        } else {
            eprintln!(
                "could not enable service (is systemd running?); file remains at {}",
                target.display()
            );
        }
    }
    Ok(())
}

fn auto_disable() -> io::Result<()> {
    if cfg!(target_os = "macos") {
        let target = PathBuf::from("/Library/LaunchDaemons/io.rasa.etcsync.plist");
        let _ = run_elevated(
            "launchctl",
            &["remove", "io.rasa.etcsync"],
        );
        let _ = run_elevated(
            "launchctl",
            &["bootout", "system", &target.to_string_lossy()],
        );
        let _ = run_elevated("rm", &["-f", &target.to_string_lossy()]);
        if !target.exists() {
            println!("auto boot sync disabled");
        } else {
            eprintln!("could not remove {}", target.display());
        }
    } else {
        let target = PathBuf::from("/etc/systemd/system/rasa-etc-sync.service");
        let _ = run_elevated("systemctl", &["disable", "--now", "rasa-etc-sync.service"]);
        let _ = run_elevated("rm", &["-f", &target.to_string_lossy()]);
        let _ = run_elevated("systemctl", &["daemon-reload"]);
        if !target.exists() {
            println!("auto boot sync disabled");
        } else {
            eprintln!("could not remove {}", target.display());
        }
    }
    Ok(())
}

fn auto_status() -> io::Result<()> {
    let (target, label) = if cfg!(target_os = "macos") {
        (
            PathBuf::from("/Library/LaunchDaemons/io.rasa.etcsync.plist"),
            "io.rasa.etcsync",
        )
    } else {
        (
            PathBuf::from("/etc/systemd/system/rasa-etc-sync.service"),
            "rasa-etc-sync.service",
        )
    };
    if target.exists() {
        println!("installed: {} ({label})", target.display());
    } else {
        println!("not installed (run `etc auto on`)");
    }
    Ok(())
}

fn status_summary() -> io::Result<()> {
    let all = files()?;
    let mut same = 0usize;
    let mut diff = 0usize;
    let mut missing = 0usize;
    for rel in &all {
        if !host_path(rel).exists() {
            missing += 1;
            continue;
        }
        match content_differs(rel) {
            Ok(false) => same += 1,
            _ => diff += 1,
        }
    }
    println!("Rasa etc -> {}", host_etc());
    println!(
        "{same} in sync, {diff} differ, {missing} not on host (of {})",
        all.len()
    );
    println!("try: etc status, etc diff, etc apply, etc auto on");
    Ok(())
}

fn usage_msg<T>(message: &str) -> io::Result<T> {
    Err(io::Error::new(
        io::ErrorKind::InvalidInput,
        format!("usage: {message}"),
    ))
}