//! A2 — system commands, root/sudo commands, and basic Linux commands for Rasa OS.
//! Registry (human-readable): `src/a2.sy`

use std::cell::RefCell;
use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

const BOLD_HINT: &str = "\x1b[1m";
const RESET_HINT: &str = "\x1b[0m";
const CYAN_HINT: &str = "\x1b[36m";
const DIM_HINT: &str = "\x1b[2m";
const GREEN_HINT: &str = "\x1b[32m";

thread_local! {
    /// Shell aliases set with `alias name=value` (session-local).
    static ALIASES: RefCell<HashMap<String, String>> = RefCell::new(HashMap::new());
    /// Command history kept for the `history` command (session-local).
    static HISTORY: RefCell<Vec<String>> = RefCell::new(Vec::new());
}

pub fn run(command: &str, args: &[String], cwd: &Path) -> Option<io::Result<()>> {
    // Session history: remember every line we see (except `history` itself)
    // so the user can look back at what they ran.
    if command != "history" {
        HISTORY.with(|history| {
            let mut history = history.borrow_mut();
            let line = if args.is_empty() {
                command.to_string()
            } else {
                format!("{command} {}", args.join(" "))
            };
            history.push(line);
            if history.len() > 200 {
                history.remove(0);
            }
        });
    }

    match command {
        // ── ROOT / SUDO ──────────────────────────────────────────
        "sudo" => Some(run_sudo(args, cwd)),
        "su" => Some(run_su(args, cwd)),
        "passwd" => Some(run_host_str("passwd", args, cwd)),

        // ── USER / IDENTITY ──────────────────────────────────────
        "whoami" => Some(run_whoami(args, cwd)),
        "users" => Some(run_users(args, cwd)),
        "id" => Some(run_id(args, cwd)),

        // ── SYSTEM (no root) ─────────────────────────────────────
        "uptime" => Some(run_host("uptime", &[], cwd)),
        "hostname" => Some(run_host("hostname", &[], cwd)),
        "df" => Some(run_df(cwd)),
        "free" => Some(run_free(cwd)),
        "ps" => Some(run_ps(args, cwd)),
        "top" => Some(run_top(cwd)),
        "htop" => Some(run_htop(args, cwd)),
        "neofetch" => Some(run_neofetch(args, cwd)),

        // ── SHELL HELPERS ────────────────────────────────────────
        "alias" => Some(run_alias(args)),
        "unalias" => Some(run_unalias(args)),
        "history" => Some(run_history(args)),

        // ── BASIC LINUX COMMANDS (host bridge, flags pass through) ──
        "man" | "tldr" => Some(run_host_str(command, args, cwd)),
        "chmod" => Some(run_host_str("chmod", args, cwd)),
        "chown" => Some(run_host_str("chown", args, cwd)),
        "kill" => Some(run_host_str("kill", args, cwd)),
        "pkill" => Some(run_host_str("pkill", args, cwd)),
        "ping" => Some(run_host_str("ping", args, cwd)),
        "which" => Some(run_host_str("which", args, cwd)),
        "whatis" => Some(run_host_str("whatis", args, cwd)),
        "wc" => Some(run_host_str("wc", args, cwd)),
        "shred" => Some(run_host_str("shred", args, cwd)),
        "less" => Some(run_host_str("less", args, cwd)),
        "tail" => Some(run_host_str("tail", args, cwd)),
        "head" => Some(run_host_str("head", args, cwd)),
        "grep" => Some(run_grep(args, cwd)),
        "unzip" => Some(run_host_str("unzip", args, cwd)),
        "zip" => Some(run_host_str("zip", args, cwd)),
        "tar" => Some(run_host_str("tar", args, cwd)),
        "gzip" => Some(run_host_str("gzip", args, cwd)),
        "gunzip" => Some(run_host_str("gunzip", args, cwd)),
        "curl" => Some(run_host_str("curl", args, cwd)),
        "wget" => Some(run_wget(args, cwd)),
        "apt" => Some(run_host_str("apt", args, cwd)),
        "apt-get" => Some(run_host_str("apt-get", args, cwd)),
        "yum" => Some(run_host_str("yum", args, cwd)),
        "dnf" => Some(run_host_str("dnf", args, cwd)),
        "pacman" => Some(run_host_str("pacman", args, cwd)),

        // Run a local / absolute executable: `./script.sh`, `./a.out`, `/bin/ls`.
        cmd if cmd.starts_with("./") || (cmd.starts_with('/') && cmd.len() > 1) => {
            Some(run_exec(cmd, args, cwd))
        }
        _ => None,
    }
}

pub fn help() {
    println!("  {CYAN_HINT}System / monitor{RESET_HINT}");
    println!("  \u{1b}[32muptime\u{1b}[0m                how long the system has been up");
    println!("  \u{1b}[32mhostname\u{1b}[0m              machine name");
    println!("  \u{1b}[32mdf\u{1b}[0m                    disk free space");
    println!("  \u{1b}[32mfree\u{1b}[0m                   memory usage");
    println!("  \u{1b}[32mps [args]\u{1b}[0m            list processes");
    println!("  \u{1b}[32mtop\u{1b}[0m                  process snapshot");
    println!("  \u{1b}[32mhtop\u{1b}[0m                 live host viewer (falls back to top)");
    println!("  \u{1b}[32mneofetch\u{1b}[0m             system / OS info (built-in if missing)");
    println!("  {CYAN_HINT}Shell helpers{RESET_HINT}");
    println!("  \u{1b}[32malias [name]\u{1b}[0m         list aliases");
    println!("  \u{1b}[32malias name='cmd'\u{1b}[0m     define an alias");
    println!("  \u{1b}[32munalias <name>|-a\u{1b}[0m    remove an alias");
    println!("  \u{1b}[32mhistory [-c|<n>]\u{1b}[0m     show this session's command history");
    println!("  \u{1b}[32m./<program> [args]\u{1b}[0m   run a local executable (or /abs/path)");
    println!("  {CYAN_HINT}Files & text{RESET_HINT}");
    println!("  \u{1b}[32mman <cmd>\u{1b}[0m, \u{1b}[32mwhatis <cmd>\u{1b}[0m             manuals / one-line docs");
    println!("  \u{1b}[32mless <file>\u{1b}[0m, \u{1b}[32mhead [<n>] <file>\u{1b}[0m      view files");
    println!("  \u{1b}[32mtail [-f] <file>\u{1b}[0m                    last lines of a file");
    println!("  \u{1b}[32mgrep <pattern> [file]\u{1b}[0m               search matching lines");
    println!("  \u{1b}[32mwc [file]\u{1b}[0m                           word / line count");
    println!("  \u{1b}[32mshred [-u] <file>\u{1b}[0m                   overwrite a file");
    println!("  \u{1b}[32mchmod\u{1b}[0m <mode> <path>, \u{1b}[32mchown\u{1b}[0m <user> <path>");
    println!("  \u{1b}[32munzip <file> [dir]\u{1b}[0m, \u{1b}[32mzip\u{1b}[0m, \u{1b}[32mtar\u{1b}[0m, \u{1b}[32mgzip\u{1b}[0m, \u{1b}[32mgunzip\u{1b}[0m   archives");
    println!("  {CYAN_HINT}Processes / net / users{RESET_HINT}");
    println!("  \u{1b}[32mkill <pid>\u{1b}[0m, \u{1b}[32mpkill <name>\u{1b}[0m            end processes");
    println!("  \u{1b}[32mping <host>\u{1b}[0m                         test network reachability");
    println!("  \u{1b}[32mwhoami\u{1b}[0m, \u{1b}[32musers\u{1b}[0m, \u{1b}[32mid [-u|-g|-un]\u{1b}[0m       current user / logged-in users / identity");
    println!("  \u{1b}[32mpasswd [user]\u{1b}[0m                       change a password");
    println!("  \u{1b}[32mwhich <program>\u{1b}[0m                     full path of a command");
    println!("  {CYAN_HINT}Packages / downloads{RESET_HINT}");
    println!("  \u{1b}[32mapt\u{1b}[0m|\u{1b}[32mapt-get\u{1b}[0m|\u{1b}[32myum\u{1b}[0m|\u{1b}[32mdnf\u{1b}[0m|\u{1b}[32mpacman\u{1b}[0m <args>   package managers");
    println!("  \u{1b}[32mwget <url>\u{1b}[0m, \u{1b}[32mcurl <url>\u{1b}[0m              download files");
    println!("  {CYAN_HINT}Root / sudo{RESET_HINT}");
    println!("  \u{1b}[32msudo res\u{1b}[0m             restart (reboot) the system");
    println!("  \u{1b}[32msudo halt\u{1b}[0m|\u{1b}[32mpoweroff\u{1b}[0m   power off the system");
    println!("  \u{1b}[32msudo shutdown\u{1b}[0m        shut down now");
    println!("  \u{1b}[32msudo -i\u{1b}[0m              interactive root login shell");
    println!("  \u{1b}[32msudo -s\u{1b}[0m              root shell");
    println!("  \u{1b}[32msudo whoami\u{1b}[0m          effective user under sudo");
    println!("  \u{1b}[32msudo id\u{1b}[0m              root identity");
    println!("  \u{1b}[32msudo passwd [user]\u{1b}[0m   change password as root");
    println!("  \u{1b}[32msudo fuckeduo\u{1b}[0m        completely uninstall Rasa OS from this system");
    println!("  \u{1b}[32msu [user]\u{1b}[0m            switch user (default: root)");
}

fn run_sudo(args: &[String], cwd: &Path) -> io::Result<()> {
    if args.is_empty() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "usage: sudo res | sudo halt | sudo poweroff | sudo shutdown | sudo -i | sudo -s | sudo whoami | sudo id | sudo passwd [user] | sudo fuckeduo",
        ));
    }

    let sub = args[0].as_str();
    let rest = &args[1..];

    match sub {
        // First A2 root command: restart the host OS
        "res" | "reboot" => {
            println!("Rasa OS: requesting system restart…");
            println!("(host will reboot if sudo is allowed)");
            io::stdout().flush().ok();
            run_privileged_reboot(cwd)
        }
        "halt" | "poweroff" => {
            println!("Rasa OS: requesting system power off…");
            io::stdout().flush().ok();
            run_privileged_poweroff(cwd)
        }
        "shutdown" => {
            println!("Rasa OS: requesting shutdown…");
            io::stdout().flush().ok();
            run_privileged_poweroff(cwd)
        }
        "-i" => run_interactive_sudo(&["-i"], cwd),
        "-s" => run_interactive_sudo(&["-s"], cwd),
        "whoami" => run_host("sudo", &["whoami"], cwd),
        "id" => run_host("sudo", &["id"], cwd),
        "passwd" => {
            let mut cmd_args: Vec<&str> = vec!["passwd"];
            let owned: Vec<String> = rest.to_vec();
            for a in &owned {
                cmd_args.push(a.as_str());
            }
            run_interactive_sudo(&cmd_args, cwd)
        }
        // Completely purge Rasa OS from the host (binary + data + cargo install)
        "fuckeduo" => run_fuckeduo(),
        other => Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!(
                "unknown sudo subcommand: {other}\ntry: sudo res, sudo halt, sudo -i, sudo whoami, sudo fuckeduo, …"
            ),
        )),
    }
}

/// Completely remove Rasa OS from this machine:
/// storage (music/data), cargo-installed `rasa` binary, and common leftover paths.
fn run_fuckeduo() -> io::Result<()> {
    println!("╔══════════════════════════════════════════════════╗");
    println!("║  Rasa OS — FUCKEDUO  (full uninstall)            ║");
    println!("║  Removing Rasa OS completely from this system…  ║");
    println!("╚══════════════════════════════════════════════════╝");
    io::stdout().flush().ok();

    let mut removed: Vec<String> = Vec::new();
    let mut warnings: Vec<String> = Vec::new();

    // 1) Application data / music storage (all known locations)
    for path in rasa_data_candidates() {
        match remove_path_tree(&path) {
            Ok(true) => removed.push(format!("data: {}", path.display())),
            Ok(false) => {}
            Err(e) => warnings.push(format!("data {}: {e}", path.display())),
        }
    }

    // 2) cargo uninstall package `rasa` (removes from cargo registry install list)
    match Command::new("cargo")
        .args(["uninstall", "rasa"])
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .output()
    {
        Ok(out) if out.status.success() => {
            removed.push("cargo package: rasa (cargo uninstall)".into());
        }
        Ok(out) => {
            let err = String::from_utf8_lossy(&out.stderr);
            let msg = err.trim();
            if !msg.is_empty()
                && !msg.contains("package `rasa` is not installed")
                && !msg.contains("is not installed")
            {
                warnings.push(format!("cargo uninstall: {msg}"));
            }
        }
        Err(e) => warnings.push(format!("cargo not available: {e}")),
    }

    // 3) Binary copies in common install locations
    for path in rasa_binary_candidates() {
        match remove_path_tree(&path) {
            Ok(true) => removed.push(format!("binary: {}", path.display())),
            Ok(false) => {}
            Err(e) => warnings.push(format!("binary {}: {e}", path.display())),
        }
    }

    // 4) which/whereis leftover — try PATH `rasa` if still present and under home
    if let Ok(which) = Command::new("which").arg("rasa").output() {
        if which.status.success() {
            let p = String::from_utf8_lossy(&which.stdout).trim().to_string();
            if !p.is_empty() {
                let path = PathBuf::from(&p);
                if is_safe_to_delete_binary(&path) {
                    match remove_path_tree(&path) {
                        Ok(true) => removed.push(format!("binary (which): {p}")),
                        Ok(false) => {}
                        Err(e) => warnings.push(format!("which rasa {p}: {e}")),
                    }
                } else {
                    warnings.push(format!(
                        "left binary at {p} (outside user install paths — remove manually if needed)"
                    ));
                }
            }
        }
    }

    println!();
    if removed.is_empty() {
        println!("Rasa OS: nothing found to remove (already clean, or never installed).");
    } else {
        println!("Rasa OS: removed:");
        for item in &removed {
            println!("  ✓ {item}");
        }
    }
    if !warnings.is_empty() {
        println!("Rasa OS: notes:");
        for w in &warnings {
            println!("  ! {w}");
        }
    }
    println!();
    println!("Rasa OS has been purged from this system.");
    println!("This shell will now exit.");
    io::stdout().flush().ok();

    // Exit process so a half-deleted binary does not keep running.
    std::process::exit(0);
}

fn home_dir() -> Option<PathBuf> {
    env::var_os("HOME")
        .map(PathBuf::from)
        .or_else(|| env::var_os("USERPROFILE").map(PathBuf::from))
        .or_else(|| {
            let drive = env::var_os("HOMEDRIVE")?;
            let path = env::var_os("HOMEPATH")?;
            let mut home = PathBuf::from(drive);
            home.push(path);
            Some(home)
        })
}

fn rasa_data_candidates() -> Vec<PathBuf> {
    let mut paths = Vec::new();

    if let Ok(custom) = env::var("RASA_OS_HOME") {
        paths.push(PathBuf::from(custom));
    }

    if let Some(home) = home_dir() {
        // macOS default
        paths.push(
            home.join("Library")
                .join("Application Support")
                .join("RasaOS"),
        );
        // Linux / XDG default
        paths.push(home.join(".local").join("share").join("rasa-os"));
        // Extra common leftovers
        paths.push(home.join(".rasa-os"));
        paths.push(home.join(".config").join("rasa-os"));
        paths.push(home.join(".config").join("RasaOS"));
        paths.push(home.join(".cache").join("rasa-os"));
        paths.push(home.join(".cache").join("RasaOS"));
    }

    if cfg!(windows) {
        if let Some(app_data) = env::var_os("APPDATA") {
            paths.push(PathBuf::from(app_data).join("RasaOS"));
        }
        if let Some(local) = env::var_os("LOCALAPPDATA") {
            paths.push(PathBuf::from(local).join("RasaOS"));
        }
    }

    paths.sort();
    paths.dedup();
    paths
}

fn rasa_binary_candidates() -> Vec<PathBuf> {
    let mut paths = Vec::new();
    let names: &[&str] = if cfg!(windows) {
        &["rasa.exe", "rasa"]
    } else {
        &["rasa"]
    };

    if let Some(home) = home_dir() {
        for name in names {
            paths.push(home.join(".cargo").join("bin").join(name));
            paths.push(home.join(".local").join("bin").join(name));
            paths.push(home.join("bin").join(name));
        }
    }

    // CARGO_HOME override
    if let Ok(cargo_home) = env::var("CARGO_HOME") {
        for name in names {
            paths.push(PathBuf::from(&cargo_home).join("bin").join(name));
        }
    }

    paths.sort();
    paths.dedup();
    paths
}

fn is_safe_to_delete_binary(path: &Path) -> bool {
    let s = path.to_string_lossy();
    // Only auto-delete under user cargo/local bins — never system paths like /usr/bin
    s.contains("/.cargo/bin/")
        || s.contains("\\.cargo\\bin\\")
        || s.contains("/.local/bin/")
        || s.contains("\\.local\\bin\\")
        || rasa_binary_candidates().iter().any(|p| p == path)
}

/// Remove a file or directory tree. Ok(true) = something was removed.
fn remove_path_tree(path: &Path) -> io::Result<bool> {
    if !path.exists() {
        return Ok(false);
    }
    if path.is_dir() {
        fs::remove_dir_all(path)?;
    } else {
        fs::remove_file(path)?;
    }
    Ok(true)
}

fn run_su(args: &[String], cwd: &Path) -> io::Result<()> {
    // `su` or `su root` or `su <user>` — interactive switch user
    let mut cmd = Command::new("su");
    if args.is_empty() {
        // default: root login shell style on Unix
        cmd.arg("-");
    } else {
        for a in args {
            cmd.arg(a);
        }
    }
    cmd.current_dir(cwd)
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit());

    let status = cmd.status()?;
    if status.success() {
        Ok(())
    } else {
        Err(io::Error::other(format!(
            "su exited with status: {status}"
        )))
    }
}

fn run_privileged_reboot(cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        return run_host("shutdown", &["/r", "/t", "0"], cwd);
    }
    // macOS / Linux
    run_host("sudo", &["shutdown", "-r", "now"], cwd)
        .or_else(|_| run_host("sudo", &["reboot"], cwd))
}

fn run_privileged_poweroff(cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        return run_host("shutdown", &["/s", "/t", "0"], cwd);
    }
    run_host("sudo", &["shutdown", "-h", "now"], cwd)
}

fn run_interactive_sudo(sudo_args: &[&str], cwd: &Path) -> io::Result<()> {
    let mut cmd = Command::new("sudo");
    for a in sudo_args {
        cmd.arg(a);
    }
    cmd.current_dir(cwd)
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit());
    let status = cmd.status()?;
    if status.success() {
        Ok(())
    } else {
        Err(io::Error::other(format!(
            "sudo exited with status: {status}"
        )))
    }
}

fn run_df(cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        return run_host("wmic", &["logicaldisk", "get", "size,freespace,caption"], cwd);
    }
    run_host("df", &["-h"], cwd)
}

fn run_free(cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        return run_host(
            "powershell",
            &[
                "-NoProfile",
                "-Command",
                "Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory,TotalVisibleMemorySize",
            ],
            cwd,
        );
    }
    if cfg!(target_os = "macos") {
        // macOS has no `free`; show vm_stat + memory pressure hint
        println!("Rasa memory (macOS vm_stat):");
        return run_host("vm_stat", &[], cwd);
    }
    run_host("free", &["-h"], cwd)
}

fn run_ps(args: &[String], cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        return run_host("tasklist", &[], cwd);
    }
    if args.is_empty() {
        run_host("ps", &["aux"], cwd)
    } else {
        let rest: Vec<&str> = args.iter().map(String::as_str).collect();
        run_host("ps", &rest, cwd)
    }
}

fn run_top(cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        return run_host("tasklist", &[], cwd);
    }
    if cfg!(target_os = "macos") {
        run_host("top", &["-l", "1", "-n", "10"], cwd)
    } else {
        run_host("top", &["-bn1"], cwd)
    }
}

// ── NEW BASIC LINUX COMMANDS ─────────────────────────────────────────

/// `htop` when the host has it, otherwise fall back to `top`.
fn run_htop(args: &[String], cwd: &Path) -> io::Result<()> {
    if command_exists("htop") {
        run_host_str("htop", args, cwd)
    } else {
        println!("{DIM_HINT}htop is not installed — showing `top` instead.{RESET_HINT}");
        run_top(cwd)
    }
}

/// `neofetch` when the host has it, otherwise a small built-in info card.
fn run_neofetch(args: &[String], cwd: &Path) -> io::Result<()> {
    if command_exists("neofetch") {
        return run_host_str("neofetch", args, cwd);
    }

    let hostname = host_output("hostname").unwrap_or_else(|_| "unknown".into());
    let user = env::var("USER")
        .or_else(|_| env::var("USERNAME"))
        .unwrap_or_else(|_| "unknown".into());
    println!(
        "{DIM_HINT}(neofetch is not installed — showing built-in Rasa info){RESET_HINT}"
    );
    println!("{GREEN_HINT}        .-+~{BOLD_HINT} Rasa OS{RESET_HINT}{GREEN_HINT}~+-.{RESET_HINT}");
    println!("{BOLD_HINT}OS{RESET_HINT}      {}", env::consts::OS);
    println!("{BOLD_HINT}Kernel{RESET_HINT}  {} (host)", env::consts::OS);
    println!("{BOLD_HINT}Arch{RESET_HINT}    {}", env::consts::ARCH);
    println!("{BOLD_HINT}Host{RESET_HINT}    {hostname}");
    println!("{BOLD_HINT}User{RESET_HINT}    {user}");
    println!("{BOLD_HINT}Shell{RESET_HINT}   Rasa (Rust terminal OS)");
    println!("{BOLD_HINT}Rasa v{RESET_HINT}  {}", env!("CARGO_PKG_VERSION"));
    println!("{BOLD_HINT}PWD{RESET_HINT}     {}", cwd.display());
    Ok(())
}

/// `wget` on hosts that have it, else emulated with `curl -O` (macOS ships curl).
fn run_wget(args: &[String], cwd: &Path) -> io::Result<()> {
    if args.is_empty() {
        return usage_str("wget <url>...");
    }
    if command_exists("wget") {
        run_host_str("wget", args, cwd)
    } else {
        println!("{DIM_HINT}wget is not installed — using `curl -O` instead.{RESET_HINT}");
        let mut curl_args = vec!["-O".to_string()];
        curl_args.extend(args.iter().cloned());
        run_host_str("curl", &curl_args, cwd)
    }
}

/// Run a local or absolute executable: `./script.sh arg`, `./a.out`, `/bin/ls`.
fn run_exec(program: &str, args: &[String], cwd: &Path) -> io::Result<()> {
    let (path, target_args): (PathBuf, &[String]) = if program == "./" {
        let Some(script) = args.first() else {
            return usage_str("./<executable> [args]");
        };
        (cwd.join(script), &args[1..])
    } else if let Some(relative) = program.strip_prefix("./") {
        (cwd.join(relative), args)
    } else {
        (PathBuf::from(program), args)
    };

    let status = Command::new(&path)
        .args(target_args)
        .current_dir(cwd)
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()?;
    if status.success() {
        Ok(())
    } else {
        Err(io::Error::other(format!(
            "{} exited with status: {status}",
            path.display()
        )))
    }
}

/// List / define shell aliases: `alias`, `alias ll='ls -l'`, `alias ll`.
fn run_alias(args: &[String]) -> io::Result<()> {
    if args.is_empty() {
        let mut entries = ALIASES
            .with(|aliases| {
                aliases
                    .borrow()
                    .iter()
                    .map(|(name, value)| (name.clone(), value.clone()))
                    .collect::<Vec<_>>()
            });
        entries.sort();
        if entries.is_empty() {
            println!("no aliases defined");
        } else {
            for (name, value) in entries {
                println!("alias {name}='{value}'");
            }
        }
        return Ok(());
    }

    for arg in args {
        if let Some((name, value)) = arg.split_once('=') {
            let name = name.trim();
            if name.is_empty() {
                continue;
            }
            ALIASES.with(|aliases| {
                aliases.borrow_mut().insert(name.to_string(), value.to_string());
            });
            println!("alias {name}='{value}'");
        } else {
            match ALIASES.with(|aliases| aliases.borrow().get(arg).cloned()) {
                Some(value) => println!("alias {arg}='{value}'"),
                None => println!("alias {arg} not found"),
            }
        }
    }
    Ok(())
}

/// Remove an alias: `unalias <name>...` or `unalias -a` to clear all.
fn run_unalias(args: &[String]) -> io::Result<()> {
    if args.is_empty() {
        return usage_str("unalias <name>... | unalias -a");
    }
    for arg in args {
        if arg == "-a" || arg == "--all" {
            ALIASES.with(|aliases| aliases.borrow_mut().clear());
            println!("all aliases removed");
            continue;
        }
        let removed = ALIASES.with(|aliases| aliases.borrow_mut().remove(arg).is_some());
        if removed {
            println!("unalias {arg}");
        } else {
            println!("alias {arg} not found");
        }
    }
    Ok(())
}

/// Show this session's command history (`history`, `history <n>`, `history -c`).
fn run_history(args: &[String]) -> io::Result<()> {
    if args.iter().any(|arg| arg == "-c" || arg == "clear") {
        HISTORY.with(|history| history.borrow_mut().clear());
        println!("history cleared");
        return Ok(());
    }

    let limit = args.iter().find_map(|arg| arg.parse::<usize>().ok());
    HISTORY.with(|history| {
        let history = history.borrow();
        if history.is_empty() {
            println!("no commands in history yet");
            return;
        }
        let start = match limit {
            Some(limit) => history.len().saturating_sub(limit),
            None => 0,
        };
        for (index, line) in history.iter().enumerate().skip(start) {
            println!("{index:>4}  {line}");
        }
    });
    Ok(())
}

/// Expand the first word of a typed line if it matches a defined alias.
/// Called by the shell before anything else, so aliases like `ll='ls -l'`
/// can target native Rasa commands too.
pub fn expand_aliases(line: &str) -> String {
    let trimmed = line.trim();
    if trimmed.is_empty() {
        return line.to_string();
    }
    let first_word_end = trimmed
        .char_indices()
        .find(|(_, character)| character.is_whitespace())
        .map(|(index, _)| index)
        .unwrap_or(trimmed.len());
    let first_word = &trimmed[..first_word_end];
    let rest = trimmed[first_word_end..].trim_start();

    let value = ALIASES.with(|aliases| aliases.borrow().get(first_word).cloned());
    match value {
        Some(value) if !rest.is_empty() => format!("{value} {rest}"),
        Some(value) => value,
        None => line.to_string(),
    }
}

fn host_output(program: &str) -> io::Result<String> {
    let output = Command::new(program).output()?;
    Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
}

/// True when the named program is available on the host PATH.
fn command_exists(program: &str) -> bool {
    let mut command = Command::new(if cfg!(windows) { "where" } else { "which" });
    command
        .arg(program)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    command
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

fn usage_str(message: &str) -> io::Result<()> {
    Err(io::Error::new(
        io::ErrorKind::InvalidInput,
        format!("usage: {message}"),
    ))
}

/// `whoami` — print the current username. Works on Unix and Windows (whoami.exe).
fn run_whoami(args: &[String], cwd: &Path) -> io::Result<()> {
    run_host_str("whoami", args, cwd)
}

/// `users` — print the users currently logged in.
/// Unix/Linux have a real `users` (reads the utmp database); on Windows we show
/// the current logged-in user instead.
fn run_users(args: &[String], cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        let user = env::var("USERNAME").unwrap_or_else(|_| "unknown".to_string());
        println!("{user}");
        return Ok(());
    }
    run_host_str("users", args, cwd)
}

/// `id` / `id -u` / `id -g` / `id -un` — user & group identity.
/// Unix/Linux call the kernel's `id`; Windows has no POSIX `id`, so `-u` maps
/// to the numeric SID via `whoami /user` and plain `id` prints the username.
fn run_id(args: &[String], cwd: &Path) -> io::Result<()> {
    if cfg!(windows) {
        if args.iter().any(|arg| arg == "-u" || arg == "-un") {
            return run_host("whoami", &["/user"], cwd);
        }
        let user = env::var("USERNAME").unwrap_or_else(|_| "unknown".to_string());
        println!("uid={user}");
        return Ok(());
    }
    run_host_str("id", args, cwd)
}

/// Run a real host program from inside Rasa OS with string arguments.
fn run_host_str(program: &str, args: &[String], cwd: &Path) -> io::Result<()> {
    let refs: Vec<&str> = args.iter().map(String::as_str).collect();
    run_host(program, &refs, cwd)
}

/// `grep` treats exit code 1 as "no lines matched" — a normal result, not an error.
fn run_grep(args: &[String], cwd: &Path) -> io::Result<()> {
    if args.is_empty() {
        return usage_str("grep <pattern> [file]...");
    }
    let refs: Vec<&str> = args.iter().map(String::as_str).collect();
    let status = Command::new("grep")
        .args(&refs)
        .current_dir(cwd)
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()?;
    match status.code() {
        Some(0) | Some(1) => Ok(()),
        _ => Err(io::Error::other(format!(
            "grep exited with status: {status}"
        ))),
    }
}

fn run_host(program: &str, args: &[&str], cwd: &Path) -> io::Result<()> {
    let status = Command::new(program)
        .args(args)
        .current_dir(cwd)
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()?;
    if status.success() {
        Ok(())
    } else {
        Err(io::Error::other(format!(
            "{program} exited with status: {status}"
        )))
    }
}
