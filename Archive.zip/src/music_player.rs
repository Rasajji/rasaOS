//! Rasa OS built-in music player.
//!
//! Plays audio (MP3 and other formats supported by rodio) inside the app.
//! Does NOT open the system/default media player.

use crossterm::event::{poll, read, Event, KeyCode};
use crossterm::terminal::{disable_raw_mode, enable_raw_mode};
use rodio::{Decoder, DeviceSinkBuilder, Player};
use std::fs::File;
use std::io::{self, Write};
use std::path::Path;
use std::time::Duration;

const RESET: &str = "\x1b[0m";
const BOLD: &str = "\x1b[1m";
const DIM: &str = "\x1b[2m";
const CYAN: &str = "\x1b[36m";
const GREEN: &str = "\x1b[32m";
const YELLOW: &str = "\x1b[33m";
const MAGENTA: &str = "\x1b[35m";

/// Simple built-in MP3/audio player for Rasa OS.
///
/// Uses rodio for decoding + playback so songs stay inside Rasa OS
/// instead of launching Finder / Music.app / xdg-open / Windows start.
pub fn play(path: &Path) -> io::Result<()> {
    if !path.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("song file not found: {}", path.display()),
        ));
    }

    let title = path
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_else(|| path.display().to_string());

    // Decode with File metadata so MP3 seeking/length works correctly.
    // Never shell out to `open` / Music.app / xdg-open.
    let file = File::open(path).map_err(|error| {
        io::Error::new(
            error.kind(),
            format!("cannot open song {}: {error}", path.display()),
        )
    })?;
    let source = Decoder::try_from(file).map_err(|error| {
        io::Error::other(format!(
            "cannot decode audio (use mp3/wav/ogg/flac): {error}"
        ))
    })?;

    // Keep `device` alive for the whole playback session.
    // Dropping it stops sound immediately.
    let device = DeviceSinkBuilder::open_default_sink().map_err(|error| {
        io::Error::other(format!("cannot open audio output device: {error}"))
    })?;
    let player = Player::connect_new(&device.mixer());
    player.append(source);

    print_header(&title);
    println!("{DIM}  engine: Rasa built-in (rodio) · not system Music app{RESET}");
    print_controls();
    print_status("Playing", 1.0, false);
    let _ = io::stdout().flush();

    enable_raw_mode()?;
    let result = run_controls(&player);
    let _ = disable_raw_mode();

    // Make sure playback stops when leaving the player UI.
    player.stop();
    println!();
    println!("{GREEN}✓{RESET} {DIM}stopped inside Rasa Music Player (no system player used){RESET}");
    result
}

fn run_controls(player: &Player) -> io::Result<()> {
    let mut volume = 1.0_f32;

    while !player.empty() {
        if poll(Duration::from_millis(200))? {
            if let Event::Key(event) = read()? {
                match event.code {
                    KeyCode::Char(' ') => {
                        if player.is_paused() {
                            player.play();
                            print_status("Playing", volume, false);
                        } else {
                            player.pause();
                            print_status("Paused ", volume, true);
                        }
                    }
                    KeyCode::Char('+') | KeyCode::Char('=') => {
                        volume = (volume + 0.1).min(2.0);
                        player.set_volume(volume);
                        print_status(
                            if player.is_paused() {
                                "Paused "
                            } else {
                                "Playing"
                            },
                            volume,
                            player.is_paused(),
                        );
                    }
                    KeyCode::Char('-') | KeyCode::Char('_') => {
                        volume = (volume - 0.1).max(0.0);
                        player.set_volume(volume);
                        print_status(
                            if player.is_paused() {
                                "Paused "
                            } else {
                                "Playing"
                            },
                            volume,
                            player.is_paused(),
                        );
                    }
                    KeyCode::Char('q') | KeyCode::Char('Q') | KeyCode::Esc => {
                        player.stop();
                        break;
                    }
                    _ => {}
                }
            }
        }
    }

    Ok(())
}

fn print_header(title: &str) {
    println!();
    println!("{MAGENTA}{BOLD}┌─ Rasa Music Player ─────────────────────┐{RESET}");
    println!(
        "{MAGENTA}{BOLD}│{RESET} {GREEN}Now playing:{RESET} {CYAN}{title}{RESET}"
    );
    println!("{MAGENTA}{BOLD}└─────────────────────────────────────────┘{RESET}");
}

fn print_controls() {
    println!(
        "{DIM}  Space pause/resume  ·  +/- volume  ·  q / Esc stop{RESET}"
    );
    println!();
}

fn print_status(state: &str, volume: f32, paused: bool) {
    let bar = volume_bar(volume);
    let state_color = if paused { YELLOW } else { GREEN };
    // Carriage return so status stays on one updating line.
    print!(
        "\r  {state_color}{BOLD}{state}{RESET}  vol {bar} {DIM}{:.0}%{RESET}   ",
        volume * 100.0
    );
    let _ = io::stdout().flush();
}

fn volume_bar(volume: f32) -> String {
    let filled = ((volume / 2.0) * 10.0).round() as usize;
    let filled = filled.min(10);
    let empty = 10 - filled;
    format!(
        "{GREEN}{}{DIM}{}{RESET}",
        "█".repeat(filled),
        "░".repeat(empty)
    )
}
