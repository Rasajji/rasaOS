use std::io;
use std::net::UdpSocket;
use std::process::Command;

pub fn run(command: &str, args: &[String]) -> Option<io::Result<()>> {
    match (command, args.first().map(String::as_str)) {
        ("my", Some("ip")) => Some(my_ip()),
        ("arp", Some("-a")) if args.len() == 1 => Some(arp_table()),
        _ => None,
    }
}

pub fn help() {
    println!("\u{1b}[32m  my ip\u{1b}[0m                   show private IP, public IP, and MAC address");
    println!("\u{1b}[32m  arp -a\u{1b}[0m                  show devices discovered on the local network");
}

fn arp_table() -> io::Result<()> {
    let status = Command::new("arp").arg("-a").status();
    match status {
        Ok(status) if status.success() => Ok(()),
        Ok(status) => Err(io::Error::other(format!(
            "ARP command exited with status: {status}"
        ))),
        Err(error) if error.kind() == io::ErrorKind::NotFound && cfg!(target_os = "linux") => {
            let status = Command::new("ip").args(["neigh", "show"]).status()?;
            if status.success() {
                Ok(())
            } else {
                Err(io::Error::other(format!(
                    "network neighbor command exited with status: {status}"
                )))
            }
        }
        Err(error) => Err(error),
    }
}

fn my_ip() -> io::Result<()> {
    println!("Rasa Network");
    println!(
        "  Private IP: {}",
        private_ip().unwrap_or_else(|| "unknown".to_string())
    );
    println!(
        "  Public IP:  {}",
        public_ip().unwrap_or_else(|| "unknown (internet needed)".to_string())
    );
    println!(
        "  MAC:      {}",
        mac_address().unwrap_or_else(|| "unknown".to_string())
    );
    Ok(())
}

fn private_ip() -> Option<String> {
    let socket = UdpSocket::bind("0.0.0.0:0").ok()?;
    if socket.connect("8.8.8.8:80").is_ok() {
        return Some(socket.local_addr().ok()?.ip().to_string());
    }

    system_ip()
}

fn public_ip() -> Option<String> {
    if cfg!(windows) {
        let script = "(Invoke-RestMethod -UseBasicParsing https://api.ipify.org).Trim()";
        return command_output("powershell", &["-NoProfile", "-Command", script])
            .and_then(|output| first_public_ip_in_text(&output));
    }

    command_output(
        "curl",
        &["-fsS", "--max-time", "5", "https://api.ipify.org"],
    )
    .or_else(|| {
        command_output(
            "curl",
            &["-fsS", "--max-time", "5", "https://ifconfig.me/ip"],
        )
    })
    .and_then(|output| first_public_ip_in_text(&output))
}

fn system_ip() -> Option<String> {
    if cfg!(windows) {
        return command_output("ipconfig", &[]).and_then(|output| first_ip_in_text(&output));
    }

    command_output("ifconfig", &[])
        .or_else(|| command_output("ip", &["addr"]))
        .and_then(|output| first_ip_in_text(&output))
}

fn mac_address() -> Option<String> {
    if cfg!(windows) {
        return command_output("getmac", &["/fo", "csv", "/nh"])
            .and_then(|output| first_mac_in_text(&output));
    }

    command_output("ifconfig", &[])
        .or_else(|| command_output("ip", &["link"]))
        .and_then(|output| first_mac_in_text(&output))
}

fn command_output(program: &str, args: &[&str]) -> Option<String> {
    let output = Command::new(program).args(args).output().ok()?;
    if !output.status.success() {
        return None;
    }
    String::from_utf8(output.stdout).ok()
}

fn first_mac_in_text(text: &str) -> Option<String> {
    text.split(|character: char| {
        character.is_whitespace() || character == ',' || character == '"' || character == '\''
    })
    .map(|token| token.trim_matches(|character| character == ':' || character == '-'))
    .find(|token| is_mac(token))
    .map(ToString::to_string)
}

fn is_mac(value: &str) -> bool {
    let separator = if value.contains(':') {
        ':'
    } else if value.contains('-') {
        '-'
    } else {
        return false;
    };

    let parts = value.split(separator).collect::<Vec<_>>();
    parts.len() == 6
        && parts.iter().all(|part| {
            part.len() == 2 && part.chars().all(|character| character.is_ascii_hexdigit())
        })
}

fn first_ip_in_text(text: &str) -> Option<String> {
    first_ipv4_in_text(text, true)
}

fn first_public_ip_in_text(text: &str) -> Option<String> {
    first_ipv4_in_text(text, false)
}

fn first_ipv4_in_text(text: &str, private_only: bool) -> Option<String> {
    text.split(|character: char| {
        character.is_whitespace()
            || character == ','
            || character == '"'
            || character == '\''
            || character == '('
            || character == ')'
    })
    .map(|token| {
        token
            .trim_start_matches("addr:")
            .trim_end_matches(|character: char| !character.is_ascii_digit())
    })
    .find(|token| {
        if private_only {
            is_private_ipv4(token)
        } else {
            is_public_ipv4(token)
        }
    })
    .map(ToString::to_string)
}

fn is_private_ipv4(value: &str) -> bool {
    let parts = value
        .split('.')
        .filter_map(|part| part.parse::<u8>().ok())
        .collect::<Vec<_>>();
    if parts.len() != 4 {
        return false;
    }

    parts[0] == 10
        || (parts[0] == 172 && (16..=31).contains(&parts[1]))
        || (parts[0] == 192 && parts[1] == 168)
}

fn is_public_ipv4(value: &str) -> bool {
    let Some(parts) = parse_ipv4(value) else {
        return false;
    };

    !is_private_ipv4(value) && parts[0] != 0 && parts[0] != 127 && parts[0] != 169 && parts[0] < 224
}

fn parse_ipv4(value: &str) -> Option<Vec<u8>> {
    let parts = value
        .split('.')
        .map(str::parse::<u8>)
        .collect::<Result<Vec<_>, _>>()
        .ok()?;

    if parts.len() == 4 {
        Some(parts)
    } else {
        None
    }
}
