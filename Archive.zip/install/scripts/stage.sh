#!/usr/bin/env bash
# Stage the built binary + bundled resources into install/payload/
# in a layout that the rasa binary understands:
#   <prefix>/bin/rasa
#   <prefix>/share/rasa/etc/...
#   <prefix>/share/rasa/vendor/neovim/...
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PAYLOAD="$ROOT/install/payload"
BIN="$ROOT/target/release/rasa"
VERSION="$(grep '^version' "$ROOT/Cargo.toml" | head -1 | cut -d'"' -f2)"
PREFIX="${1:-/usr/local}"

if [ ! -x "$BIN" ]; then
  echo "release binary not found; building…" >&2
  (cd "$ROOT" && cargo build --release)
fi

rm -rf "$PAYLOAD"
REL_BIN="${PREFIX#/}/bin/rasa"
REL_SHARE="${PREFIX#/}/share/rasa"

mkdir -p "$PAYLOAD/$(dirname "$REL_BIN")"
cp "$BIN" "$PAYLOAD/$REL_BIN"
chmod 755 "$PAYLOAD/$REL_BIN"

mkdir -p "$PAYLOAD/$REL_SHARE"
cp -R "$ROOT/etc" "$PAYLOAD/$REL_SHARE/etc"
mkdir -p "$PAYLOAD/$REL_SHARE/vendor"
cp -R "$ROOT/vendor/neovim" "$PAYLOAD/$REL_SHARE/vendor/neovim"

echo "staged $VERSION -> $PAYLOAD (prefix $PREFIX)"