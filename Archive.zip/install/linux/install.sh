#!/usr/bin/env bash
# Rasa OS Linux installer (one-click: ./install.sh)
# Installs to /usr/local/bin + /usr/local/share/rasa (or --prefix=<dir>).
set -euo pipefail

PREFIX=/usr/local
for arg in "$@"; do
  case "$arg" in
    --prefix=*) PREFIX="${arg#--prefix=}" ;;
  esac
done

BIN="$PREFIX/bin/rasa"
DECL="$PREFIX/share/rasa"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

if ! command -v sudo >/dev/null && [ "$(id -u)" -ne 0 ]; then
  echo "need root to install to $PREFIX (rerun with sudo, or --prefix=~/.local)" >&2
  exit 1
fi

run() {
  if [ "$(id -u)" -eq 0 ]; then "$@"; else sudo "$@"; fi
}

echo "Rasa OS installer -> $PREFIX"
run mkdir -p "$BIN" "$DECL"
run install -m 755 "$ROOT/install/payload/usr/local/bin/rasa" "$BIN/rasa"
run cp -R "$ROOT/install/payload/usr/local/share/rasa/etc" "$DECL/etc"
run cp -R "$ROOT/install/payload/usr/local/share/rasa/vendor" "$DECL/vendor"

touch "$HOME/.vimrc" 2>/dev/null || true
if [ -x "$BIN/rasa" ]; then
  echo "installed. run: rasa os"
else
  echo "install failed" >&2
  exit 1
fi