#!/usr/bin/env bash
# Build a .deb for Debian/Ubuntu from the staged payload.
# Must run on Linux (needs dpkg-deb). Produces install/RasaOS-<ver>-amd64.deb
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
VERSION="$(grep '^version' "$ROOT/Cargo.toml" | head -1 | cut -d'"' -f2)"
SRC="$ROOT/install/payload"
PKGDIR="$ROOT/install/linux/RasaOS_$VERSION"

command -v dpkg-deb >/dev/null || { echo "dpkg-deb required (run on Linux via ./install/linux/build-deb.sh)" >&2; exit 1; }

bash "$ROOT/install/scripts/stage.sh" /usr/local

rm -rf "$PKGDIR"
mkdir -p "$PKGDIR/DEBIAN" "$PKGDIR/usr/local/bin" "$PKGDIR/usr/local/share/rasa"
cp "$SRC/usr/local/bin/rasa" "$PKGDIR/usr/local/bin/rasa"
cp -R "$SRC/usr/local/share/rasa/etc" "$PKGDIR/usr/local/share/rasa/etc"
cp -R "$SRC/usr/local/share/rasa/vendor" "$PKGDIR/usr/local/share/rasa/vendor"

cat > "$PKGDIR/DEBIAN/control" <<EOF
Package: rasa-os
Version: $VERSION
Section: utils
Priority: optional
Architecture: amd64
Maintainer: Rasa OS <rasa@example.org>
Description: Rasa OS CLI - a tiny terminal OS shell in Rust
 Terminal OS-like shell with music, files, editor, and system tools.
EOF

dpkg-deb --build "$PKGDIR" "$ROOT/install/RasaOS_${VERSION}_amd64.deb" >/dev/null
rm -rf "$PKGDIR"
echo "built: $ROOT/install/RasaOS_${VERSION}_amd64.deb"