#!/usr/bin/env bash
# Build a portable tar.gz for Linux from the staged payload.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
VERSION="$(grep '^version' "$ROOT/Cargo.toml" | head -1 | cut -d'"' -f2)"
ARCH="$(uname -m)"
OUT="$ROOT/install/RasaOS-${VERSION}-linux-${ARCH}.tar.gz"

(cd "$ROOT/install/payload" && tar czf "$OUT" .)
echo "built: $OUT"