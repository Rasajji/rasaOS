# Rasa OS — Installers

One-click installers for macOS, Linux, and Windows. The binary is
self-contained: it finds `etc/` and the bundled Neovim from its own install
directory (priority: `RASA_OS_HOME` → next to the executable → source tree).

## Build

```bash
cd "Rasa oS CLI"
./build-installers.sh        # host-aware: builds what this OS can
```

### Per platform

| OS      | Command                                | Output |
| ------- | -------------------------------------- | ------ |
| macOS   | `install/macos/build-pkg.sh`           | `install/RasaOS-<ver>-macos-<arch>.pkg` |
| Linux   | `install/linux/build-deb.sh`           | `install/RasaOS-<ver>_amd64.deb` |
| Linux   | `install/linux/make-tarball.sh`        | `install/RasaOS-<ver>-linux-<arch>.tar.gz` |
| Windows | `install/windows/install.bat`          | `install/RasaOS-<ver>-windows-x86_64.zip` |

> Cross-building for other OSes needs that OS's toolchain (a Linux with
> `dpkg-deb`, or Windows where the `.bat` runs). On any host you can still
> produce the portable payload with `install/scripts/stage.sh`.

## Install (user)

- **macOS**: double-click the `.pkg`, follow the wizard. Installs to
  `/usr/local/bin/rasa` and `/usr/local/share/rasa`, PATH is set via
  `/etc/paths.d/rasa`.
- **Linux**: `sudo ./install/linux/install.sh`
  or `sudo dpkg -i install/RasaOS-<ver>_amd64.deb`.
  Tarball: `tar xzf RasaOS-*.tar.gz -C / && rasa os`.
- **Windows**: unzip `RasaOS-<ver>-windows-x86_64.zip`, right-click
  `install.bat` → *Run as administrator*. Copies `rasa.exe` + `etc\` to
  `%LOCALAPPDATA%\RasaOS` and adds it to PATH. Build the exe locally with
  `cargo build --release`, or let the GitHub Actions workflow build all
  three platforms on every push/tag.

## Verify

```bash
rasa os        # starts the terminal shell
rasa etc list  # configs from the installed etc/ (not the source tree)
vi notes.txt   # opens the bundled Neovim
```

## Notes

- The Rust toolchain builds a static-ish binary; Neovim is bundled as-is so
  no external editor is required.
- `etc apply`/`etc auto` write to the real system `/etc/` (sudo). Dangerous
  files (`passwd`, `shadow`, `sudoers`, `fstab`, `crontab`) require
  `etc apply --force`.