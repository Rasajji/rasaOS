# Rasa OS CLI

Rasa OS CLI is a terminal OS-like shell written in Rust. It starts with `rasa os`
and opens a colorful command environment in your terminal.

## Run

```bash
cargo run -- os
```

## Install

From this project folder:

```bash
cargo install --path .
```

Then open any terminal and run:

```bash
rasa os
```

If your terminal cannot find `rasa`, add Cargo's bin directory to your PATH:

- macOS/Linux: add `export PATH="$HOME/.cargo/bin:$PATH"` to `~/.zshrc` or `~/.bashrc`
- Windows PowerShell: add `%USERPROFILE%\.cargo\bin` to the user PATH environment variable

## Commands

- UI: `/`, `help`, `about`, `banner`, `clear`, `exit`, `shutdown`
- Files: `pwd`, `ls`/`dir`, `cd`, `mkdir`, `touch`, `cat`, `write`, `append`, `rm`/`del`, `cp`/`copy`, `mv`/`move`, `tree`, `find`
- System: `whoami`, `date`, `uname`, `sysinfo`
- Custom A1: `my ip`
- Custom A2 (system/root): `uptime`, `hostname`, `df`, `free`, `ps`, `top`, `sudo res`, `sudo halt`, `su`, …
- Apps: `music list`, `music add <path>`, `music remove <name>`, `music open <name>`, `music storage`
- Host bridge: `run <program> [args]` or `! <program> [args]`
- Syscall bridge: `<anything> -cas` — put `-cas` at the end of any line to run it
  as a real system call on the host kernel (docker, git, curl, brew, ps, …) and
  stream the output into the Rasa terminal. Example: `docker ps -cas`

## Deep Kernel Talk (`syscall`)

Beyond the `-cas` host bridge, Rasa OS can issue **raw system calls** straight
against the host kernel through `libc`:

```text
syscall getpid         # the kernel process ID of Rasa OS
syscall uname          # kernel: sysname, nodename, release, version, machine
syscall stat Cargo.toml# inode-level metadata (size, mode, uid/gid, times, blocks)
syscall clock          # kernel realtime + monotonic clocks (uptime source)
syscall cwd            # current dir straight from the getcwd syscall
syscall page           # kernel virtual-memory page size (sysconf _SC_PAGESIZE)
syscall kill <pid> <sig>   # deliver a raw signal via kill(2)
syscall proc           # live kernel process table (/proc on Linux, ps on macOS)
syscall list           # list every supported kernel call
syscall                # interactive "kernel talk mode": a persistent syscall> prompt
```

On Linux, `/proc/<pid>/stat` is read directly; on macOS the process table falls
back to `ps`. The module that implements all of this is `src/syscall.rs`.

## System-Call Bridge (`src/syscall.rs`)

Rasa OS is not a bootable kernel yet, so its "system calls" (`سیستم کال`) are
forwarded to the host OS kernel: the trailing `-cas` flag turns any Rasa input
into a real host command (`docker`, `git`, `curl`, `brew`, …) that runs in the
current Rasa working directory, and its stdout/stderr are printed back inside
Rasa OS.

```text
rasa:~/docker$ docker ps -cas
```

## Custom Commands

### A1 — network (`src/A1.rs`)

- `my ip`: prints your private IP, public IP, and first detected MAC address.
- `arp -a`: local network discovery table.

### A2 — system & root (`src/a2.sy` registry, `src/A2.rs` implementation)

System (no root):

- `uptime`, `hostname`, `df`, `free`, `ps [args]`, `top`
- `htop` (falls back to `top` if not installed), `neofetch` (built-in card if missing)

Shell helpers:

- `alias` / `alias ll='ls -l'` / `unalias <name>|-a` — session aliases
- `history`, `history <n>`, `history -c` — session command history
- `./<program> [args]` — run a local executable (also `/abs/path` executables)

Basic Linux commands (host bridge — flags pass straight through):

- Manuals & text: `man`, `whatis`, `less`, `head`, `tail`, `grep`, `wc`, `shred`
- Permissions: `chmod`, `chown`
- Processes / net / users: `kill`, `pkill`, `ping`, `passwd`, `which`, `whoami`, `users`, `id` (with `-u`, `-g`, `-un`; Windows maps `-u` to the numeric SID)
- Archives: `unzip`, `zip`, `tar`, `gzip`, `gunzip`
- Downloads: `wget` (falls back to `curl -O` on macOS), `curl`
- Package managers: `apt`, `apt-get`, `yum`, `dnf`, `pacman`

Root / sudo:

- `sudo res` — **restart the host system** (first A2 root command)
- `sudo halt` / `sudo poweroff` / `sudo shutdown` — power off
- `sudo -i`, `sudo -s` — root shell
- `sudo whoami`, `sudo id`, `sudo passwd [user]`
- `sudo fuckeduo` — **completely uninstall Rasa OS** (binary, cargo install, storage/data)
- `su` / `su root` — switch user to root

Command list is also documented in `src/a2.sy` (system section and root section are separate).

## Slash Panel

Inside Rasa OS, type:

```text
/
```

This opens the Rasa Panel. The first app is `Music`.

Easy song import:

1. Open `rasa os`
2. Type `/`
3. Open `Music`
4. Choose `Add song to Rasa OS`
5. Drag & drop the song file from Finder/Downloads into the terminal
6. Press `Enter`

You can also type:

```text
music add 
```

Then drag & drop the song file after the command and press `Enter`.

Controls:

- `↑` / `↓`: move selection
- `Enter`: open selected item
- `Esc` or `q`: close/back

Music files are copied into Rasa OS storage instead of using the system music
library directly. You can add songs from anywhere, then manage them from Rasa OS.

Playback uses the **built-in Rasa Music Player** (`src/music_player.rs`) via
`rodio` — it does **not** open the system media player (Music.app, Finder,
Windows Media Player, xdg-open, etc.).

Player controls while a song is playing:

- `Space`: pause / resume
- `+` / `-`: volume up / down
- `q` or `Esc`: stop

Default storage locations:

- macOS: `~/Library/Application Support/RasaOS/music`
- Linux: `~/.local/share/rasa-os/music`
- Windows: `%APPDATA%\RasaOS\music`

You can override the storage root with `RASA_OS_HOME`.

## Cross-platform notes

- Works on macOS, Linux, and Windows with stable Rust.
- Uses `crossterm` for cross-platform TUI keyboard controls.
- Supports `~` home paths on Unix and Windows.
- Uses ANSI UI by default and falls back to `cmd /C cls` for clear on Windows.
- File permissions are detected on Unix; Windows executable coloring is conservative.

This is not a bootable kernel yet. It is the first usable terminal layer for Rasa OS.
